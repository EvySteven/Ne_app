import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)

    let registrar = engineBridge.pluginRegistry.registrar(forPlugin: "NeLocalPrivacy")
    let channel = FlutterMethodChannel(
      name: "bf.ne.neapp/local_privacy",
      binaryMessenger: registrar.messenger()
    )
    channel.setMethodCallHandler { call, result in
      guard call.method == "excludeDatabaseDirectoryFromBackup",
            let path = call.arguments as? String else {
        result(FlutterMethodNotImplemented)
        return
      }

      let directoryURL = URL(fileURLWithPath: path, isDirectory: true)
      do {
        try FileManager.default.createDirectory(
          at: directoryURL,
          withIntermediateDirectories: true
        )
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        var mutableDirectoryURL = directoryURL
        try mutableDirectoryURL.setResourceValues(values)

        let verified = try mutableDirectoryURL.resourceValues(
          forKeys: [.isExcludedFromBackupKey]
        ).isExcludedFromBackup ?? false
        guard verified else {
          result(FlutterError(
            code: "BACKUP_EXCLUSION_FAILED",
            message: "Le dossier de données Né n’est pas exclu des sauvegardes iCloud.",
            details: nil
          ))
          return
        }
        result(true)
      } catch {
        result(FlutterError(
          code: "BACKUP_EXCLUSION_FAILED",
          message: error.localizedDescription,
          details: nil
        ))
      }
    }
  }
}

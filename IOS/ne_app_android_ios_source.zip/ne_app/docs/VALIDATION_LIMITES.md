# Validation, tests et limites du prototype

## Contrôles automatisés réalisés

Sur le Sandbox Linux, avec Flutter **3.47.5**, Dart **3.13.4**, Java **21** et Android SDK **36** :

```text
flutter analyze  → No issues found
flutter test     → 12 tests passed
flutter build apk --release → réussi
```

Les tests unitaires couvrent le calcul des prochaines règles, la fiabilité selon le nombre d’intervalles réellement observés, le filtrage d’une valeur aberrante, l’âge de grossesse et la priorité à une date confirmée, ainsi que le contrat HTTP Anoushka par `MockClient`. Aucun appel réel à Render ni partage de donnée utilisateur n’a été effectué.

### APK Android générée

- Fichier : `build/app/outputs/flutter-apk/app-release.apk`.
- Taille : environ **72,5 Mo**.
- `aapt` : package `bf.ne.ne_app`, version `1.0.0` (code `1`), minSdk `24`, targetSdk `36`.
- `apksigner verify` : signature APK valide; build de test signé par la clé **debug**.
- SHA-256 : `e1610acd600531ba340364737c02268b8f01022cf2a79caab6f9dd4101ff1131`.
- Elle n’a pas été installée/exécutée sur un téléphone Android physique par ce Sandbox.

Le build émet un avertissement non bloquant : le projet et `flutter_timezone` utilisent encore le plugin Kotlin Gradle traditionnel. Le build actuel réussit, mais cette intégration devra être migrée vers Kotlin intégré ou une version compatible avant une future mise à niveau Flutter qui supprimera la compatibilité.

### État iOS

Le squelette iOS Flutter, l’identité « Né », le minimum iOS 15.0, les notifications Darwin, le réglage Keychain appareil seul et le canal Swift d’exclusion de sauvegarde SQLCipher sont présents dans la source. **Aucun build iOS n’a été exécuté** : l’environnement courant est Linux et n’inclut ni macOS, ni Xcode, ni CocoaPods. Le simulateur, la signature, l’ouverture native de SQLCipher, le canal Swift et le comportement d’exclusion/restauration iCloud doivent être vérifiés sur un Mac et au moins un iPhone réel. Voir [Build iOS sur Mac](BUILD_IOS_MAC.md).

## Limites connues

1. **Contenu médical** : les articles embarqués sont des textes de démonstration. Aucune validation médicale, obstétricale ou locale n’a été obtenue.
2. **Suivi grossesse par semaine** : l’application permet de naviguer entre les semaines et affiche des repères d’organisation, mais elle n’inclut pas encore de contenu clinique détaillé de développement, symptômes ou soins par semaine.
3. **Prédiction de cycle** : les durées utilisées pour le niveau de fiabilité sont mesurées entre des dates successives réellement notées; la durée habituelle ne sert qu’au premier repère. L’algorithme reste une heuristique de calendrier; ses seuils et sa valeur clinique ne sont pas validés. Il ne confirme pas l’ovulation, ne permet pas d’exclure une grossesse et n’est pas contraceptif.
4. **Anoushka** : seule la page publique et le contrat visible ont été consultés. L’API, le fournisseur de modèle, la rétention, l’exactitude, la disponibilité et les mécanismes d’effacement restent à vérifier. L’IA peut répondre de façon erronée.
5. **Langues** : le français fonctionne; Mooré et Dioula sont des options en préparation sans traduction validée.
6. **Communauté** : absente du MVP. La modération, la protection contre le harcèlement et la confidentialité doivent précéder toute fonction sociale.
7. **Notifications** : Android utilise des rappels inexactes; iOS utilise le planificateur système. Les systèmes peuvent retarder ou suspendre les alertes. Le chemin iOS attend sa première compilation et ses essais sur appareil.
8. **Localisation et accessibilité** : textes et formats principalement français; aucune revue complète de VoiceOver, TalkBack, contraste, Dynamic Type et tailles d’écran n’a été réalisée.
9. **Distribution Android** : signature debug uniquement; l’APK n’est pas prête pour Play Store ou un usage public.
10. **Build iOS et distribution Apple** : projet source présent, mais la compilation/signature requiert un Mac avec Xcode, une configuration de signature et un Bundle ID unique. Aucune IPA n’a été produite ici.
11. **Build Android futur** : avertissement de migration Kotlin Gradle pour `flutter_timezone`; build actuel réussi, mais compatibilité à maintenir lors des mises à niveau.

## Vérifications manuelles avant pilote

### Android

- [ ] Installer et lancer sur des appareils Android physiques API 24+ et API 33+.
- [ ] Essayer les parcours cycle, conception, grossesse et « comprendre mon corps » du début à la fin.
- [ ] Vérifier saisies improbables, dates passées/futures, cycles irréguliers et « pas assez de données ».
- [ ] Vérifier la priorité de la date obstétricale confirmée si les dates se contredisent.
- [ ] Vérifier les notifications autorisées/refusées, la mise en veille et le redémarrage Android.
- [ ] Vérifier que l’application reste utile sans connexion et que le chat n’envoie pas de message avant acceptation.
- [ ] Vérifier le contenu exact du payload à l’aide des journaux de test du serveur avant le pilote, sans données réelles de santé.
- [ ] Tester export JSON/CSV et effacement; confirmer qu’aucune trace de base ni de clé ne reste après effacement.

### iOS

- [ ] Installer, lancer et naviguer sur simulateur Xcode, puis tester sur iPhone réel iOS 15+.
- [ ] Vérifier les plugins CocoaPods/SPM, SQLCipher, signature et consentement de notifications.
- [ ] Vérifier le canal Swift, l’attribut `isExcludedFromBackup`, une sauvegarde/restauration iCloud et la perte de clé sur données fictives.
- [ ] Tester export/feuille native de partage, effacement, thème sombre, VoiceOver, Dynamic Type, safe areas et tailles d’écran.
- [ ] Confirmer l’absence de transfert réseau avant accord Anoushka et la déconnexion hors ligne.

### Toutes plateformes

- [ ] Obtenir revue médicale, juridique/confidentialité et linguistique avant distribution publique.
- [ ] Configurer des signatures release propres à chaque plateforme; stocker les secrets hors du dépôt; auditer les dépendances natives.

## Critères de publication

Ne pas publier ni présenter Né comme une application de santé certifiée tant que le contenu clinique, les données, les calculs, le serveur Anoushka, le consentement, la sécurité Android/iOS, l’accessibilité et les signatures de distribution n’ont pas été revus par les personnes compétentes.

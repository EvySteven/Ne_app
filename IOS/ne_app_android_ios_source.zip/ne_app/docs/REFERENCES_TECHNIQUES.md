# Références techniques consultées

Consultation : 1 octobre 2026. Les versions de packages ci-dessous sont celles verrouillées dans `pubspec.lock` et résolues dans le Sandbox.

## Flutter et outils de compilation

- Version de l’environnement : Flutter stable 3.47.5, Dart 3.13.4, Java 21, Android SDK 36 / Build Tools 36.0.0.
- Flutter a confirmé la toolchain Android; le build APK Android est possible dans ce Sandbox Linux.
- La cible iOS générée utilise un minimum iOS 15.0. Ce Sandbox ne dispose pas de macOS, Xcode ou CocoaPods; aucune compilation/simulation iOS n’a donc été effectuée.
- Configuration officielle Flutter iOS : https://docs.flutter.dev/platform-integration/ios/setup
- Build et publication iOS officiels : https://docs.flutter.dev/deployment/ios
- Exécution Xcode sur simulateur/appareil Apple : https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices

## Packages

| Package | Version | Usage / contraintes vérifiées |
|---|---:|---|
| [`flutter_local_notifications`](https://pub.dev/packages/flutter_local_notifications) | 22.3.1 | Notifications locales Android/iOS; permissions iOS via `IOSFlutterLocalNotificationsPlugin.requestPermissions`; planification zonée avec timezone. |
| [`sqflite_sqlcipher`](https://pub.dev/packages/sqflite_sqlcipher) | 3.4.1 | SQLite SQLCipher, ouverture avec `password`; iOS utilise CocoaPods et le pod `SQLCipher`; fork communautaire à revoir avant production. |
| [`flutter_secure_storage`](https://pub.dev/packages/flutter_secure_storage) | 11.2.0 | Clé de base protégée par la plateforme; iOS configuré avec Keychain `first_unlock_this_device` et `synchronizable: false`. |
| [`flutter_timezone`](https://pub.dev/packages/flutter_timezone) | 5.1.0 | Fuseau IANA local via `FlutterTimezone.getLocalTimezone()` et `identifier`. |
| [`share_plus`](https://pub.dev/packages/share_plus) | 13.3.0 | Feuille native de partage Android/iOS; API `SharePlus.instance.share(ShareParams(files: ...))`; Flutter >= 3.38.1. |
| [`table_calendar`](https://pub.dev/packages/table_calendar) | 3.2.1 | Calendrier mensuel et marqueurs personnalisés. |
| [`shared_preferences`](https://pub.dev/packages/shared_preferences) | 2.5.5 | Préférences non sensibles de thème, langue et onboarding. |
| [`intl`](https://pub.dev/packages/intl) | 0.20.3 | Formatage français des dates. |
| [`path_provider`](https://pub.dev/packages/path_provider) | 2.1.6 | Création temporaire des fichiers d’export. |
| [`http`](https://pub.dev/packages/http) | 1.6.0 | Appel explicite de l’API Anoushka après consentement. |
| [`timezone`](https://pub.dev/packages/timezone) | 0.11.1 | Fuseaux horaires des notifications planifiées. |
| [`cross_file`](https://pub.dev/packages/cross_file) | `pubspec.lock` | Fichiers transmis à la feuille de partage. |

Documentation des configurations :

- Android : notifications/manifest https://pub.dev/packages/flutter_local_notifications#androidmanifestxml-setup
- Android : stockage sécurisé et auto-backup https://pub.dev/packages/flutter_secure_storage#android
- SQLCipher et règle ProGuard Android : https://pub.dev/packages/sqflite_sqlcipher
- API de partage : https://pub.dev/packages/share_plus#share-files
- iOS : `ios/Runner/AppDelegate.swift` applique et vérifie `isExcludedFromBackup` au dossier SQLCipher; à valider sur appareil réel.

## API Anoushka fournie par la fondatrice

- URL sélectionnée explicitement : https://anoushka.onrender.com/
- La page publique appelle `POST /api/chat` avec `message` et `session_id`, puis lit `reponse` et `source` facultative.
- Elle appelle aussi `POST /api/proposer` pour les contributions, mais cette route n’est pas utilisée par Né.
- Aucune question de santé réelle n’a été transmise pendant le développement; les tests du client HTTP utilisent un mock local.
- Le document de référence mentionne également `https://ne-chatbot-backend.onrender.com` comme autre origine FastAPI; cette origine n’est pas utilisée dans ce build.
- La conservation des messages côté Render et fournisseur d’IA, les conditions d’utilisation et le niveau de protection du service n’ont pas été audités.
- Toute clé ou secret administrateur présent dans une pièce jointe doit être révoqué et retiré des fichiers distribuables; il n’est pas reproduit dans ce projet.

# Installation, exécution et tests multiplateformes

## Environnement requis

- Flutter stable **3.47.5** ou une version ultérieure compatible avec les contraintes de `pubspec.yaml`.
- Dart **3.13.4** fourni avec Flutter 3.47.5.
- Pour Android : Android Studio avec Android SDK **36**, Android Build Tools et Android SDK Command-line Tools.
- Java **17 ou 21** (le build Android vérifié utilise Java 21).
- Pour iOS : **Mac avec Xcode**, CocoaPods et une cible iOS minimale de **15.0**. Les instructions pas à pas sont dans [Build iOS sur Mac](BUILD_IOS_MAC.md).
- Environ 5 Go d’espace libre pour Flutter, Android SDK, dépendances et caches de compilation Android; Xcode et les simulateurs iOS demandent un espace additionnel important.
- Pour installer sur un téléphone Android : câble USB ou transfert manuel de l’APK; le débogage USB est nécessaire pour `adb install`.

Le manifeste Android compilé cible SDK 36 et accepte Android API 24 ou ultérieur (`minSdk = 24`). Le projet iOS requiert iOS 15.0 ou ultérieur. Les fichiers locaux/générés (`android/local.properties`, `.dart_tool/`, `build/`, `ios/Flutter/Generated.xcconfig`, `ios/Flutter/ephemeral/`) ne doivent pas être partagés dans le ZIP source.

## Installer Flutter et le SDK Android

Ces étapes sont nécessaires pour exécuter ou compiler l’app Android sur Windows, macOS ou Linux. L’APK peut être produit depuis chacun de ces systèmes.

1. Installer Flutter stable en suivant le [guide Flutter officiel](https://docs.flutter.dev/get-started/install).
2. Installer Android Studio et, dans **SDK Manager**, sélectionner Android SDK Platform 36 et Android SDK Build-Tools 36.x. Installer les Command-line Tools.
3. Ajouter `flutter/bin` au `PATH`.
4. Dans un terminal :

```bash
flutter doctor
flutter doctor --android-licenses
```

Accepter les licences Android et s’assurer que la rubrique Android toolchain ne comporte pas d’erreur bloquante. Le wrapper Gradle est inclus et Flutter régénère le chemin local du SDK lors du build.

## Installer les dépendances et lancer les tests Dart

Depuis un terminal à la racine du projet :

```bash
flutter pub get
flutter analyze
flutter test
```

Ces commandes fonctionnent aussi sur Windows/Linux pour la partie Dart, même si Xcode n’est pas disponible.

### Windows (PowerShell)

```powershell
cd C:\chemin\vers\ne_app
flutter pub get
flutter analyze
flutter test
flutter run
```

### macOS / Linux

```bash
cd /chemin/vers/ne_app
flutter pub get
flutter analyze
flutter test
flutter run
```

`flutter run` choisit un appareil connecté ou un simulateur disponible. Windows/Linux peuvent exécuter Android; **la cible iOS ne peut pas être compilée par Flutter que depuis macOS avec Xcode**.

## Essayer sur un appareil Android

1. Sur le téléphone, activer les options développeur, puis **Débogage USB**.
2. Brancher le téléphone et accepter l’empreinte de l’ordinateur sur l’écran du téléphone.
3. À la racine du projet :

```bash
flutter devices
flutter run -d <identifiant_affiché>
```

Si `adb` est disponible :

```bash
adb devices
adb install -r build/app/outputs/flutter-apk/app-debug.apk
```

La première utilisation crée la base chiffrée et sa clé locale. Si l’application est désinstallée, les données locales peuvent être perdues; exporter avant toute opération susceptible d’effacer l’application.

## Générer et installer l’APK Android

Commande de test :

```bash
flutter build apk --release
```

Fichier produit :

```text
build/app/outputs/flutter-apk/app-release.apk
```

Installation USB :

```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

Pour le transfert manuel, copier l’APK sur le téléphone, ouvrir le fichier et autoriser l’installation de cette source si Android le demande. N’envoyer l’APK qu’à des testeuses de confiance.

> Le build release de ce prototype est signé avec la clé **debug** configurée dans `android/app/build.gradle.kts`. Il est adapté aux essais locaux uniquement. Avant publication, créer et protéger un keystore de publication et garder les secrets hors du dépôt.

## Exécuter et compiler sur iOS

Un Mac avec Xcode est obligatoire pour lancer l’application iOS sur simulateur/iPhone ou produire une IPA. Le détail des prérequis, réglages de signature, commandes et tests est dans [Build iOS sur Mac](BUILD_IOS_MAC.md).

En bref sur le Mac :

```bash
flutter pub get
flutter doctor -v
flutter devices
flutter run -d <identifiant_iphone_ou_simulateur>
```

Après sélection d’une équipe de signature et d’un Bundle ID unique dans Xcode, la commande de build iOS est :

```bash
flutter build ipa --release --build-name 1.0.0 --build-number 1
```

L’IPA n’est **pas** une APK. La procédure ne peut pas être exécutée sur Windows/Linux; la signature et la distribution à d’autres utilisatrices dépendent de la configuration Apple.

## Tests et contrôles

À chaque modification :

```bash
flutter pub get
flutter analyze
flutter test
```

Les tests couvrent les estimations de cycle, les seuils de fiabilité, la priorité de la date obstétricale confirmée, le calcul depuis les dernières règles et le contrat réseau Anoushka avec un client HTTP simulé. Ils n’appellent pas l’API Render.

Test manuel recommandé sur Android :

- onboarding, pseudo et changement de thème;
- saisie de cycles, dates hors plage et fiabilité affichée;
- dates des deux types de grossesse et priorité de la date confirmée;
- rendez-vous, notifications autorisées/refusées et rappel après redémarrage;
- export JSON/CSV et effacement local complet;
- chat : refuser puis accepter le dialogue de consentement, couper Internet, effacer la conversation;
- mise en veille, redémarrage, désinstallation et comportement de restauration;
- textes français, tailles de police Android augmentées, thème sombre et TalkBack.

Pour iOS, effectuer également la checklist simulateur/iPhone dans [Build iOS sur Mac](BUILD_IOS_MAC.md), en particulier l’autorisation de notifications, le canal d’exclusion iCloud, la feuille de partage native, VoiceOver et Dynamic Type.

## Dépannage Android

### Licence Android manquante

```bash
flutter doctor --android-licenses
```

### Nettoyer les caches de build

```bash
flutter clean
flutter pub get
flutter build apk --release
```

### L’appareil ne paraît pas dans `flutter devices`

Vérifier le câble, activer le débogage USB, accepter l’autorisation sur le téléphone puis relancer `adb devices`. Sous Windows, installer le pilote USB du fabricant.

### Rappels absents

Vérifier l’autorisation de notification, les réglages de l’application et les restrictions batterie du téléphone. Android peut retarder ou suspendre les alarmes inexactes; iOS peut également différer des alertes selon ses politiques système.

### Chat indisponible

Le suivi local et les articles continuent hors ligne. Anoushka requiert Internet et un backend compatible; Render peut mettre le serveur en veille, changer son API ou limiter son usage. Aucune donnée de profil n’est envoyée automatiquement.

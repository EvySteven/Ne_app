# Confidentialité et sécurité — prototype Né

Ce document décrit le comportement configuré du prototype, pas une certification, un audit complet ni un avis juridique. Les réglages iOS doivent encore être vérifiés sur appareil réel; le contenu doit être revu avant un pilote public.

## Données et emplacements

| Donnée | Emplacement configuré | Partagée automatiquement ? |
|---|---|---|
| Pseudo, objectif, dates de grossesse | Table `profile` de SQLite chiffré SQLCipher | Non; pas de synchronisation Né |
| Dates, durées et notes de cycle | Table `cycles` de SQLite chiffré | Non; pas de synchronisation Né |
| Rendez-vous, lieu, notes | Table `appointments` de SQLite chiffré | Non; pas de synchronisation Né |
| Thème, langue, état onboarding, état/délai des rappels | `SharedPreferences` sur Android; préférences système sur iOS | Non vers Né; aucune donnée de santé ni pseudo ne doit y être ajoutée |
| Conversation Anoushka | Mémoire du widget tant qu’il est ouvert | Seule une question envoyée après accord va au serveur; pas de synchronisation locale de conversation |
| Export JSON/CSV | Fichier temporaire, puis destination choisie via la feuille native de partage | Oui seulement après action d’export; la copie partagée sort du contrôle de Né |

La base SQLCipher utilise un secret aléatoire généré sur l’appareil et conservé par `flutter_secure_storage` : Android utilise le stockage sécurisé Android; iOS utilise le Keychain, configuré non synchronisable et `first_unlock_this_device`.

### Sauvegardes système

- **Android :** l’auto-backup de l’application est désactivé dans le manifeste pour éviter de restaurer la base sans sa clé.
- **iOS :** `AppDelegate.swift` marque le dossier de base avec `isExcludedFromBackup = true` avant l’ouverture de SQLCipher; le code vérifie le résultat et refuse d’ouvrir la base si l’exclusion échoue. La clé iOS est configurée pour ne pas se synchroniser par iCloud Keychain et ne pas migrer vers un autre appareil.
- Le projet iOS n’a pas été compilé sur Mac ni testé lors d’une sauvegarde/restauration iCloud dans ce Sandbox Linux. Le comportement doit être confirmé sur un vrai iPhone avant tout pilote.
- Les préférences non sensibles peuvent être incluses dans une sauvegarde système selon la plateforme. Né n’ajoute aucun mécanisme de synchronisation ou de sauvegarde santé dans le cloud; cela ne constitue pas une garantie générale sur les sauvegardes du système d’exploitation.

La chiffrement local ne remplace pas une évaluation de sécurité ou une conformité aux lois applicables. Une clé perdue rend la base chiffrée illisible.

## Ce qui est envoyé à Anoushka

Origine sélectionnée : `https://anoushka.onrender.com`. L’application n’envoie rien lorsque l’écran est ouvert, lorsque le texte est saisi ou lorsque la personne refuse le dialogue. Pour chaque question explicitement envoyée après acceptation, le JSON transmis est limité à :

```json
{
  "message": "le texte saisi par l’utilisatrice",
  "session_id": "identifiant aléatoire éphémère"
}
```

Aucun pseudo, but de parcours, date de cycle, date de grossesse, rendez-vous, note locale, numéro d’appareil ou clé n’est ajouté intentionnellement au payload. L’identifiant sert à relier les messages de la conversation et est renouvelé lorsque l’utilisatrice efface le chat.

Le message reste libre et peut inclure une donnée personnelle si l’utilisatrice l’écrit. L’interface conseille de ne pas saisir nom, téléphone, adresse ou identifiants. L’application exige HTTPS pour l’API.

### Limites du consentement

- Le serveur Render et le fournisseur du modèle peuvent recevoir la question pour produire une réponse.
- La conservation, les journaux, l’éventuelle revue humaine, les sous-traitants et la juridiction du service n’ont pas été vérifiés.
- L’application n’a pas confirmé le comportement d’API au moyen d’une question réelle; les tests du client sont mockés.
- Effacer la conversation dans l’application efface son affichage local et crée un nouvel identifiant, mais ne demande pas d’effacement à Render.
- L’étiquette « IA » et la mise en garde médicale n’établissent pas la fiabilité ou la conformité du service.

Pour lancer avec une autre origine HTTPS compatible :

```bash
flutter run --dart-define=ANOUSHKA_API_BASE_URL=https://votre-service.example
flutter build apk --release --dart-define=ANOUSHKA_API_BASE_URL=https://votre-service.example
```

Ne pas intégrer de clé API privée dans l’APK ou l’IPA; tout secret embarqué dans un client mobile peut être extrait.

## Notifications

Les rappels sont des notifications locales, avec un texte générique qui ne cite ni rendez-vous, ni dates, ni cycle. Android utilise des alarmes inexactes; iOS utilise le planificateur natif. Les deux systèmes exigent une autorisation de notification et peuvent refuser, regrouper ou retarder une alerte selon les réglages, l’état du téléphone et les politiques système. Né ne promet pas une arrivée à une heure exacte.

## Export et suppression

L’export contient des données sensibles : pseudo, dates, rendez-vous, lieux et notes, ainsi que les préférences non médicales de thème, langue et rappels. Il demande une action dans Profil et un choix explicite JSON ou CSV. Né tente de supprimer le fichier temporaire après l’appel à la feuille native de partage; une copie enregistrée ou envoyée par l’application choisie reste hors du contrôle de Né.

La suppression demande deux confirmations et efface la base, la clé sécurisée, les préférences et les rappels connus sur l’appareil. Elle n’efface pas les exports externes ni les données éventuellement retenues côté Render. Avant une désinstallation ou une restauration, exporter les données si une copie est souhaitée; il n’existe pas de synchronisation Né.

## Contrôles à faire avant un pilote public

- Publier une notice de confidentialité précisant finalités, bases, durées de conservation et voies de contact.
- Auditer le serveur, Render et le fournisseur d’IA, y compris journaux, rétention, localisation et suppression.
- Vérifier les exigences de protection des données et des données de santé dans les territoires de test.
- Tester l’exclusion de sauvegarde, la restauration, la perte de clé et l’effacement sur Android et iOS réels.
- Faire un audit de dépendances et de sécurité, un test de pénétration et une revue des configurations natives/signatures.
- Établir un protocole de contenu santé et de gestion des urgences; faire relire articles et calculs par des professionnels.
- Ne pas distribuer l’APK debug, une IPA de développement ou l’app store avant signature release et revues compétentes.

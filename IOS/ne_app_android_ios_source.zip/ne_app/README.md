# Né — application Flutter Android et iOS

**Né** est un prototype local en français pour le suivi du cycle, des repères de fertilité, l’éducation à la santé reproductive et un suivi calendaire de grossesse. Le projet est écrit en Flutter/Dart et contient désormais les cibles **Android et iOS**.

> La cible iOS nécessite macOS et Xcode pour être compilée/signée. Ce Sandbox Linux ne peut donc pas produire de `.ipa`. Le build Android, lui, peut être créé sur Windows, macOS ou Linux avec Flutter et Android SDK. Un APK est uniquement destiné à Android.

> Ce prototype n’est pas un dispositif médical. Les estimations ne constituent pas un diagnostic, une contraception ni un suivi prénatal. Les articles et les contenus informatifs restent à faire valider par des professionnels avant toute diffusion publique.

## Fonctions présentes

- Onboarding animé et illustré, choix d’objectif et pseudo facultatif.
- Thèmes clair rose pâle/blanc et sombre rose foncé/noir doux.
- Suivi local des dates de règles, durée des cycles et calendrier avec fiabilité de prédiction explicitée.
- Parcours conception avec fenêtre fertile indiquée comme estimative, jamais comme confirmation d’ovulation ou contraception.
- Parcours grossesse : âge gestationnel, priorité à une date d’accouchement confirmée par un professionnel, trame interactive de 42 semaines et gestion locale des rendez-vous/rappels.
- Articles embarqués accessibles hors ligne, signalés comme contenus de démonstration à relire.
- Anoushka identifiée comme une IA. Aucune question n’est transmise avant l’accord de l’utilisatrice. Après accord, seuls le texte saisi et un identifiant de session aléatoire sont envoyés au serveur choisi; aucun champ du profil n’est ajouté automatiquement.
- Profil avec changement de pseudo/objectif, export JSON ou CSV, préférences de notification et effacement local à double confirmation.
- Notifications et feuille de partage natives configurées pour Android/iOS; l’autorisation de notification est demandée au moment où l’utilisatrice active les rappels.
- Sur iOS, la clé SQLCipher est conservée dans le Keychain non synchronisable; le dossier de base est configuré pour être exclu des sauvegardes iCloud (à vérifier sur appareil réel).

## Démarrage rapide sur PC

1. Installer Flutter stable compatible avec `pubspec.yaml`; pour l’APK, installer aussi Android Studio/Android SDK 36 et Java 17 ou 21.
2. Décompresser le ZIP du projet et ouvrir un terminal à la racine de `ne_app`.
3. Lancer :

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

4. Brancher un téléphone Android avec le débogage USB activé, accepter la demande sur le téléphone, puis lancer `flutter devices` et `flutter run -d <identifiant>`. Les détails sont dans [Installation et tests](docs/INSTALLATION_TESTS.md).

## Générer une APK Android pour essai

```bash
flutter build apk --release
```

L’APK sera créée dans `build/app/outputs/flutter-apk/app-release.apk`. Pour l’installer par USB :

```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

Cette configuration de test signe le build release avec la clé debug Android. **Elle n’est pas destinée au Google Play ni à une distribution publique.** Voir les limites dans [Validation et limites](docs/VALIDATION_LIMITES.md).

## Exécuter et construire iOS

Il faut un **Mac avec Xcode**; Windows/Linux ne peuvent pas produire de build iOS. Sur Mac, ouvrir [le guide iOS](docs/BUILD_IOS_MAC.md) et suivre les étapes de configuration, d’essai sur simulateur/iPhone et de signature. La commande de build IPA est `flutter build ipa --release`; le Bundle ID doit être unique et signé par une équipe Apple pour l’installation/distribution prévue.

## Architecture du projet

```text
lib/
  app.dart, app_controller.dart, main.dart
  core/                     thèmes et formatage
  models/                   profil, cycles, rendez-vous, prédictions, articles
  screens/                  onboarding, accueil, calendrier, articles, Anoushka, profil
  services/                 SQLCipher, calculs, notifications, exports, API
  widgets/                  illustrations vectorielles dessinées en code
assets/data/articles.json   articles embarqués hors ligne
android/                    application et permissions Android
ios/                         Runner Xcode, AppDelegate Swift et réglages iOS
 docs/                       cadrage, installation, confidentialité et validation
 test/                       tests des règles de calcul et du client HTTP simulé
```

- Base locale : SQLite chiffrée via SQLCipher.
- Clé de base : Android Keystore via stockage sécurisé; iOS Keychain avec option appareil seulement.
- Sauvegarde : Android auto-backup désactivé; iOS dossier SQLCipher marqué exclu d’iCloud; comportement à confirmer sur matériel iOS.
- Préférences d’interface : `shared_preferences`; aucune donnée médicale ne doit y être ajoutée.
- Rappels : notifications locales discrètes, autorisation système requise.
- API conversationnelle : `https://anoushka.onrender.com` par défaut. Le client peut être reconfiguré par `--dart-define=ANOUSHKA_API_BASE_URL=https://...`; utiliser uniquement une origine HTTPS compatible avec `/api/chat`.

Pour les décisions détaillées, consulter [Installation et tests](docs/INSTALLATION_TESTS.md), [Build iOS sur Mac](docs/BUILD_IOS_MAC.md), [Architecture](docs/ARCHITECTURE.md), [Confidentialité et sécurité](docs/CONFIDENTIALITE_SECURITE.md), [Validation et limites](docs/VALIDATION_LIMITES.md) et [Références techniques](docs/REFERENCES_TECHNIQUES.md).

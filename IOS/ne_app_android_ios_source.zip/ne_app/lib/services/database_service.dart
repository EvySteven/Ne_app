import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_sqlcipher/sqflite.dart';

import '../models/appointment_model.dart';
import '../models/cycle_model.dart';
import '../models/profile_model.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  static const _keyName = 'ne_database_key_v1';
  static const MethodChannel _iosPrivacyChannel = MethodChannel(
    'bf.ne.neapp/local_privacy',
  );
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    iOptions: IOSOptions(
      accessibility: KeychainAccessibility.first_unlock_this_device,
      synchronizable: false,
    ),
  );
  Database? _database;
  String? _databasePath;

  Future<Database> get database async {
    if (_database != null && _database!.isOpen) return _database!;
    final key = await _getOrCreateKey();
    final databaseDirectory = await getDatabasesPath();
    _databasePath = p.join(databaseDirectory, 'ne_app.db');
    if (Platform.isIOS) {
      final excluded = await _iosPrivacyChannel.invokeMethod<bool>(
        'excludeDatabaseDirectoryFromBackup',
        databaseDirectory,
      );
      if (excluded != true) {
        throw StateError(
          'Le dossier de données Né n’a pas pu être exclu des sauvegardes iCloud.',
        );
      }
    }
    _database = await openDatabase(
      _databasePath!,
      password: key,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE profile (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            nickname TEXT NOT NULL DEFAULT '',
            goal TEXT NOT NULL DEFAULT 'cycle',
            last_menstrual_period TEXT,
            due_date TEXT,
            due_date_confirmed INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE cycles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_date TEXT NOT NULL UNIQUE,
            cycle_length INTEGER NOT NULL CHECK(cycle_length BETWEEN 15 AND 60),
            period_length INTEGER NOT NULL CHECK(period_length BETWEEN 1 AND 15),
            notes TEXT NOT NULL DEFAULT ''
          )
        ''');
        await db.execute('''
          CREATE TABLE appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            date_time TEXT NOT NULL,
            place TEXT NOT NULL DEFAULT '',
            reminder_minutes INTEGER NOT NULL DEFAULT 60,
            notes TEXT NOT NULL DEFAULT ''
          )
        ''');
      },
    );
    return _database!;
  }

  Future<String> _getOrCreateKey() async {
    final saved = await _secureStorage.read(key: _keyName);
    if (saved != null && saved.isNotEmpty) return saved;
    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    final created = base64UrlEncode(bytes);
    await _secureStorage.write(key: _keyName, value: created);
    return created;
  }

  Future<UserProfile?> loadProfile() async {
    final rows = await (await database).query(
      'profile',
      where: 'id = 1',
      limit: 1,
    );
    return rows.isEmpty ? null : UserProfile.fromMap(rows.first);
  }

  Future<void> saveProfile(UserProfile profile) async {
    await (await database).insert(
      'profile',
      profile.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<CycleRecord>> loadCycles() async {
    final rows = await (await database).query(
      'cycles',
      orderBy: 'start_date ASC',
    );
    return rows.map(CycleRecord.fromMap).toList(growable: false);
  }

  Future<int> saveCycle(CycleRecord cycle) async => (await database).insert(
    'cycles',
    cycle.toMap()..remove('id'),
    conflictAlgorithm: ConflictAlgorithm.replace,
  );

  Future<void> deleteCycle(int id) async =>
      (await database).delete('cycles', where: 'id = ?', whereArgs: [id]);

  Future<List<AppointmentRecord>> loadAppointments() async {
    final rows = await (await database).query(
      'appointments',
      orderBy: 'date_time ASC',
    );
    return rows.map(AppointmentRecord.fromMap).toList(growable: false);
  }

  Future<int> saveAppointment(AppointmentRecord appointment) async =>
      (await database).insert(
        'appointments',
        appointment.toMap()..remove('id'),
      );

  Future<void> deleteAppointment(int id) async =>
      (await database).delete('appointments', where: 'id = ?', whereArgs: [id]);

  Future<Map<String, dynamic>> exportSnapshot() async {
    final profile = await loadProfile();
    final cycles = await loadCycles();
    final appointments = await loadAppointments();
    return {
      'exported_at': DateTime.now().toIso8601String(),
      'format_version': 1,
      'profile': profile?.toMap(),
      'cycles': cycles.map((e) => e.toMap()).toList(),
      'appointments': appointments.map((e) => e.toMap()).toList(),
      'notice': 'Données exportées à la demande de l’utilisatrice. Né ne contrôle pas les copies partagées.',
    };
  }

  Future<void> eraseEverything() async {
    final db = _database;
    final path = _databasePath ?? p.join(await getDatabasesPath(), 'ne_app.db');
    if (db != null && db.isOpen) await db.close();
    _database = null;
    await deleteDatabase(path);
    await _secureStorage.delete(key: _keyName);
    _databasePath = null;
  }

  Future<void> close() async {
    if (_database?.isOpen ?? false) await _database!.close();
    _database = null;
  }
}

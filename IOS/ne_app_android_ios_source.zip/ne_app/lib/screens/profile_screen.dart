import 'package:flutter/material.dart';

import '../app_controller.dart';
import '../models/profile_model.dart';
import '../services/export_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mon profil')),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 28),
      children: [
        _profileCard(context),
        const SizedBox(height: 12),
        _section(context, 'Préférences', [
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14),
            secondary: const Icon(Icons.dark_mode_outlined),
            title: const Text('Mode sombre'),
            subtitle: const Text('Rose foncé et noir doux'),
            value: controller.themeMode == ThemeMode.dark,
            onChanged: (value) =>
                controller.setTheme(value ? ThemeMode.dark : ThemeMode.light),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.language_outlined),
            title: const Text('Langue'),
            subtitle: Text(
              controller.languageCode == 'fr'
                  ? 'Français'
                  : controller.languageCode,
            ),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _showLanguages(context),
          ),
        ]),
        const SizedBox(height: 12),
        _section(context, 'Rappels sur ce téléphone', [
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14),
            secondary: const Icon(Icons.notifications_active_outlined),
            title: const Text('Activer les notifications'),
            subtitle: const Text(
              'Les rappels ont un texte discret sur l’écran verrouillé.',
            ),
            value: controller.remindersEnabled,
            onChanged: (value) async {
              final granted = await controller.setRemindersEnabled(value);
              if (!context.mounted) return;
              if (value && !granted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Autorise les notifications dans les réglages de ton appareil pour recevoir les rappels.',
                    ),
                  ),
                );
              }
            },
          ),
          if (controller.remindersEnabled) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Rappel de cycle',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Combien de jours avant la date estimée ?',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [1, 2, 3]
                        .map(
                          (days) => ChoiceChip(
                            label: Text('$days jour${days == 1 ? '' : 's'}'),
                            selected: controller.cycleReminderDays == days,
                            onSelected: (_) =>
                                controller.setCycleReminderDays(days),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),
            ),
          ],
        ]),
        const SizedBox(height: 12),
        _section(context, 'Tes données', [
          ListTile(
            leading: const Icon(Icons.ios_share_outlined),
            title: const Text('Exporter mes données'),
            subtitle: const Text(
              'Profil, cycle, rendez-vous et préférences · JSON ou CSV.',
            ),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _export(context),
          ),
          const Divider(height: 1),
          ListTile(
            leading: Icon(
              Icons.delete_forever_outlined,
              color: Theme.of(context).colorScheme.error,
            ),
            title: Text(
              'Supprimer toutes mes données',
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
            subtitle: const Text(
              'Efface le profil, le cycle, les rendez-vous et les préférences de cet appareil.',
            ),
            onTap: () => _confirmDelete(context),
          ),
        ]),
        const SizedBox(height: 12),
        _section(context, 'À propos de Né', [
          const ListTile(
            leading: Icon(Icons.lock_outline_rounded),
            title: Text('Stockage local chiffré'),
            subtitle: Text(
              'Les données de cycle et de grossesse ne sont pas synchronisées dans le cloud.',
            ),
          ),
          const Divider(height: 1),
          const ListTile(
            leading: Icon(Icons.smart_toy_outlined),
            title: Text('Anoushka est une IA'),
            subtitle: Text(
              'Une question n’est envoyée à son serveur qu’après ton accord. Seuls le texte saisi et un identifiant de session aléatoire sont envoyés; aucun contexte du profil n’est ajouté.',
            ),
          ),
          const Divider(height: 1),
          const ListTile(
            leading: Icon(Icons.health_and_safety_outlined),
            title: Text('Information, pas diagnostic'),
            subtitle: Text(
              'Né et Anoushka ne remplacent pas une professionnelle de santé. Les articles de cette version sont des exemples à faire valider.',
            ),
          ),
          const Divider(height: 1),
          const ListTile(
            leading: Icon(Icons.info_outline_rounded),
            title: Text('Version de test'),
            subtitle: Text('Prototype local 1.0 · Android'),
          ),
        ]),
        const SizedBox(height: 10),
        Text(
          'Pour préserver ta confidentialité, évite d’inscrire un nom complet dans les notes. Quand tu exportes un fichier ou envoies une question à Anoushka, cette action sort du stockage local selon l’option choisie.',
          style: Theme.of(context).textTheme.bodySmall,
          textAlign: TextAlign.center,
        ),
      ],
    ),
  );

  Widget _profileCard(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: Theme.of(context).colorScheme.secondary
                .withValues(alpha: .45),
            child: Icon(
              Icons.person_outline_rounded,
              size: 28,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  controller.profile.nickname.isEmpty
                      ? 'Ton pseudo'
                      : controller.profile.nickname,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 3),
                Text(
                  controller.profile.goal.label,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Modifier le pseudo',
            onPressed: () => _editNickname(context),
            icon: const Icon(Icons.edit_outlined),
          ),
          PopupMenuButton<UserGoal>(
            tooltip: 'Changer d’objectif',
            icon: const Icon(Icons.tune_rounded),
            onSelected: (goal) => controller.updateProfile(
              controller.profile.copyWith(goal: goal),
            ),
            itemBuilder: (_) => UserGoal.values
                .map(
                  (goal) => PopupMenuItem(value: goal, child: Text(goal.label)),
                )
                .toList(),
          ),
        ],
      ),
    ),
  );

  Widget _section(BuildContext context, String title, List<Widget> children) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 5, bottom: 7),
            child: Text(title, style: Theme.of(context).textTheme.titleMedium),
          ),
          Card(child: Column(children: children)),
        ],
      );

  Future<void> _editNickname(BuildContext context) async {
    final text = TextEditingController(text: controller.profile.nickname);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Modifier ton pseudo'),
        content: TextField(
          controller: text,
          maxLength: 30,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Pseudo',
            prefixIcon: Icon(Icons.person_outline_rounded),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, text.text.trim()),
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
    text.dispose();
    if (value != null) {
      await controller.updateProfile(
        controller.profile.copyWith(nickname: value),
      );
    }
  }

  Future<void> _showLanguages(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Langue de l’application',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.check_circle_outline),
              title: const Text('Français'),
              subtitle: const Text('Disponible'),
              onTap: () {
                controller.setLanguage('fr');
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.hourglass_bottom_rounded),
              title: const Text('Mooré'),
              subtitle: const Text('Traduction à valider avant activation'),
              onTap: () => _showUnavailable(context, 'Mooré'),
            ),
            ListTile(
              leading: const Icon(Icons.hourglass_bottom_rounded),
              title: const Text('Dioula'),
              subtitle: const Text('Traduction à valider avant activation'),
              onTap: () => _showUnavailable(context, 'Dioula'),
            ),
          ],
        ),
      ),
    );
  }

  void _showUnavailable(BuildContext context, String language) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('La traduction $language n’est pas encore relue.'),
      ),
    );
  }

  Future<void> _export(BuildContext context) async {
    final format = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Exporter mes données'),
        content: const Text(
          'Le fichier contiendra ton pseudo, tes dates et rendez-vous. Choisis soigneusement l’application de destination : Né ne contrôle pas les copies exportées.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 'csv'),
            child: const Text('CSV'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, 'json'),
            child: const Text('JSON'),
          ),
        ],
      ),
    );
    if (format == null) return;
    try {
      final data = await controller.exportData();
      if (format == 'csv') {
        await ExportService().shareCsv(data);
      } else {
        await ExportService().shareJson(data);
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('L’export n’a pas pu être préparé.')),
        );
      }
    }
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final first = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Supprimer toutes tes données ?'),
        content: const Text(
          'Cette action efface définitivement les données Né de cet appareil : pseudo, cycle, grossesse, rendez-vous et préférences. Elle est irréversible. Les fichiers déjà exportés ne seront pas supprimés.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Garder mes données'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Continuer'),
          ),
        ],
      ),
    );
    if (first != true || !context.mounted) return;
    final second = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Dernière vérification'),
        content: const Text(
          'Confirme-tu l’effacement maintenant ? Tu devras refaire l’onboarding pour utiliser Né.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Supprimer définitivement'),
          ),
        ],
      ),
    );
    if (second != true) return;
    await controller.eraseAllData();
    if (!context.mounted) return;
    Navigator.of(context).popUntil((route) => route.isFirst);
  }
}

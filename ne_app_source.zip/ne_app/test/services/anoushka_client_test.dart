import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:ne_app/services/anoushka_client.dart';

void main() {
  test('le client envoie uniquement message et session_id à l’API choisie', () async {
    Map<String, dynamic>? payload;
    Uri? endpoint;
    final client = AnoushkaClient(
      client: MockClient((request) async {
        endpoint = request.url;
        payload = jsonDecode(request.body) as Map<String, dynamic>;
        return http.Response(jsonEncode({'reponse': 'Réponse de test', 'source': 'Exemple'}), 200);
      }),
    );

    final reply = await client.ask('Question de test', 'session_random_test');
    expect(endpoint?.host, 'anoushka.onrender.com');
    expect(endpoint?.path, '/api/chat');
    expect(payload, {'message': 'Question de test', 'session_id': 'session_random_test'});
    expect(reply.text, 'Réponse de test');
    expect(reply.source, 'Exemple');
    client.close();
  });

  test('identifiant de session généré sans pseudo ni donnée de profil', () {
    final first = AnoushkaClient.createEphemeralSessionId();
    final second = AnoushkaClient.createEphemeralSessionId();
    expect(first, startsWith('session_'));
    expect(first, isNot(second));
    expect(first.toLowerCase(), isNot(contains('awa')));
  });
}

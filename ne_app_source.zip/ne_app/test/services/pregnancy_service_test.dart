import 'package:flutter_test/flutter_test.dart';
import 'package:ne_app/models/profile_model.dart';
import 'package:ne_app/services/pregnancy_service.dart';

void main() {
  const service = PregnancyService();

  test('une date confirmée par un professionnel est prioritaire sur les dernières règles', () {
    final profile = UserProfile(
      nickname: 'Awa',
      goal: UserGoal.pregnancy,
      lastMenstrualPeriod: DateTime(2025, 1, 1),
      confirmedDueDate: DateTime(2025, 10, 8),
      dueDateConfirmed: true,
    );
    final age = service.age(profile, today: DateTime(2025, 9, 10));
    expect(age, isNotNull);
    expect(age!.usesConfirmedDueDate, isTrue);
    expect(age.weeks, 37);
    expect(age.days, 0);
  });

  test('les dernières règles servent de base si aucune date confirmée n’est saisie', () {
    final profile = UserProfile(
      nickname: '',
      goal: UserGoal.pregnancy,
      lastMenstrualPeriod: DateTime(2025, 1, 1),
      confirmedDueDate: DateTime(2025, 10, 8),
      dueDateConfirmed: false,
    );
    final age = service.age(profile, today: DateTime(2025, 3, 29));
    expect(age!.usesConfirmedDueDate, isFalse);
    expect(age.weeks, 13);
    expect(age.days, 3);
  });

  test('une grossesse sans date ne reçoit pas d’âge inventé', () {
    final profile = const UserProfile(nickname: '', goal: UserGoal.pregnancy);
    expect(service.age(profile, today: DateTime(2025, 3, 1)), isNull);
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:ne_app/models/cycle_model.dart';
import 'package:ne_app/models/cycle_prediction.dart';
import 'package:ne_app/services/prediction_service.dart';

void main() {
  const service = PredictionService();
  final records = <CycleRecord>[
    CycleRecord(startDate: DateTime(2025, 1, 1), cycleLength: 28, periodLength: 5),
    CycleRecord(startDate: DateTime(2025, 1, 29), cycleLength: 28, periodLength: 5),
    CycleRecord(startDate: DateTime(2025, 2, 26), cycleLength: 28, periodLength: 5),
    CycleRecord(startDate: DateTime(2025, 3, 26), cycleLength: 28, periodLength: 5),
  ];

  test('la prédiction utilise les intervalles entre les dates réellement notées', () {
    final result = service.predict(records, today: DateTime(2025, 4, 1));
    expect(result, isNotNull);
    expect(result!.nextPeriodStart, DateTime(2025, 4, 23));
    expect(result.cycleDay, 7);
    expect(result.averageCycleLength, 28);
    expect(result.sampleCount, 3);
    expect(result.reliability, ReliabilityLevel.medium);
  });

  test('une seule date fournit un repère initial sans prétendre à une observation', () {
    final result = service.predict([records.first], today: DateTime(2025, 1, 2));
    expect(result!.nextPeriodStart, DateTime(2025, 1, 29));
    expect(result.sampleCount, 0);
    expect(result.reliability, ReliabilityLevel.insufficient);
  });

  test('deux dates ne donnent pas une fiabilité artificiellement haute', () {
    final result = service.predict(records.take(2).toList(), today: DateTime(2025, 2, 10));
    expect(result!.reliability, ReliabilityLevel.insufficient);
    expect(result.sampleCount, 1);
  });

  test('six intervalles réguliers peuvent indiquer une fiabilité haute', () {
    final sevenStarts = List.generate(7, (i) => CycleRecord(
          startDate: DateTime(2025, 1, 1).add(Duration(days: 28 * i)),
          cycleLength: 28,
          periodLength: 5,
        ));
    final result = service.predict(sevenStarts, today: DateTime(2025, 6, 18));
    expect(result!.reliability, ReliabilityLevel.high);
    expect(result.sampleCount, 6);
  });

  test('les durées aberrantes sont filtrées quand l’échantillon est suffisant', () {
    expect(service.filterOutliers([28, 28, 28, 28, 28, 60]), [28, 28, 28, 28, 28]);
  });

  test('une liste vide ne fabrique pas une date', () {
    expect(service.predict(const []), isNull);
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:ne_app/models/profile_model.dart';

void main() {
  test('les quatre objectifs du parcours sont disponibles', () {
    expect(UserGoal.values.map((goal) => goal.label), containsAll([
      'Suivre mes règles',
      'Tomber enceinte',
      'Suivre ma grossesse',
      'Comprendre mon corps',
    ]));
  });
}

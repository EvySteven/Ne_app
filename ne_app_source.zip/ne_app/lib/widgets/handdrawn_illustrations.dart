import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/profile_model.dart';

class BloomingFlower extends StatelessWidget {
  const BloomingFlower({super.key, required this.progress, this.size = 180});

  final double progress;
  final double size;

  @override
  Widget build(BuildContext context) => CustomPaint(
        size: Size.square(size),
        painter: _BloomPainter(
          progress: progress.clamp(0, 1),
          petal: Theme.of(context).colorScheme.primary,
          soft: Theme.of(context).colorScheme.secondary,
          center: const Color(0xFFD4A843),
          ink: Theme.of(context).colorScheme.onSurface,
        ),
      );
}

class GoalIllustration extends StatelessWidget {
  const GoalIllustration({super.key, required this.goal, this.size = 70});
  final UserGoal goal;
  final double size;

  @override
  Widget build(BuildContext context) => CustomPaint(
        size: Size.square(size),
        painter: _GoalPainter(
          goal: goal,
          rose: Theme.of(context).colorScheme.primary,
          soft: Theme.of(context).colorScheme.secondary,
          ink: Theme.of(context).colorScheme.onSurface,
          sage: const Color(0xFF8C9D79),
          gold: const Color(0xFFD4A843),
        ),
      );
}

class _BloomPainter extends CustomPainter {
  const _BloomPainter({required this.progress, required this.petal, required this.soft, required this.center, required this.ink});
  final double progress;
  final Color petal;
  final Color soft;
  final Color center;
  final Color ink;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2 - 2);
    final radius = size.shortestSide * .205;
    final petalLength = size.shortestSide * .22;
    final petalWidth = size.shortestSide * .115;
    final edge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = ink.withValues(alpha: .55);
    final fill = Paint()..style = PaintingStyle.fill;
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(-.12 + .12 * progress);
    for (var i = 0; i < 8; i++) {
      final angle = 2 * math.pi * i / 8;
      canvas.save();
      canvas.rotate(angle);
      final opening = .56 + .44 * progress;
      final path = Path()
        ..moveTo(0, -radius * .18)
        ..cubicTo(-petalWidth * opening, -radius - petalLength * opening * .35, -petalWidth * .78, -radius - petalLength, 0, -radius - petalLength)
        ..cubicTo(petalWidth * .78, -radius - petalLength, petalWidth * opening, -radius - petalLength * opening * .35, 0, -radius * .18)
        ..close();
      fill.color = i.isEven ? petal.withValues(alpha: .76) : soft.withValues(alpha: .9);
      canvas.drawPath(path, fill);
      canvas.drawPath(path, edge);
      canvas.restore();
    }
    final centerPaint = Paint()..color = center;
    canvas.drawCircle(Offset.zero, size.shortestSide * .075, centerPaint);
    final dot = Paint()..color = Colors.white.withValues(alpha: .8);
    canvas.drawCircle(const Offset(-3, -2), 1.4, dot);
    canvas.drawCircle(const Offset(3, 2), 1, dot);
    // Fine hand-drawn stem and two leaves.
    final stem = Paint()..color = const Color(0xFF82926F)..style = PaintingStyle.stroke..strokeWidth = 2.1..strokeCap = StrokeCap.round;
    final stemPath = Path()..moveTo(0, radius * .6)..quadraticBezierTo(4, radius * 1.6, -1, size.shortestSide * .42);
    canvas.drawPath(stemPath, stem);
    final leafPaint = Paint()..color = const Color(0xFFB8C8A7).withValues(alpha: .9);
    final leafEdge = Paint()..color = const Color(0xFF71845F)..style = PaintingStyle.stroke..strokeWidth = 1.1;
    final left = Path()..moveTo(0, radius * 1.45)..quadraticBezierTo(-size.width * .36, radius * 1.18, -size.width * .33, radius * 1.55)..quadraticBezierTo(-size.width * .17, radius * 1.7, 0, radius * 1.45)..close();
    canvas.drawPath(left, leafPaint); canvas.drawPath(left, leafEdge);
    final right = Path()..moveTo(0, radius * 1.82)..quadraticBezierTo(size.width * .33, radius * 1.5, size.width * .35, radius * 1.86)..quadraticBezierTo(size.width * .16, radius * 2.02, 0, radius * 1.82)..close();
    canvas.drawPath(right, leafPaint); canvas.drawPath(right, leafEdge);
    // A few loose petals, intentionally subtle.
    final loose = Paint()..color = soft.withValues(alpha: .82)..style = PaintingStyle.fill;
    for (var i = 0; i < 3; i++) {
      final x = size.width * (.18 + i * .28);
      final y = size.height * (.23 + (i % 2) * .18);
      canvas.save(); canvas.translate(x, y); canvas.rotate(.5 + i * .65);
      canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: 7, height: 13), loose);
      canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BloomPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.petal != petal || oldDelegate.soft != soft;
}

class _GoalPainter extends CustomPainter {
  const _GoalPainter({required this.goal, required this.rose, required this.soft, required this.ink, required this.sage, required this.gold});
  final UserGoal goal;
  final Color rose;
  final Color soft;
  final Color ink;
  final Color sage;
  final Color gold;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.shortestSide;
    final line = Paint()..color = ink.withValues(alpha: .75)..style = PaintingStyle.stroke..strokeWidth = 1.7..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    final shade = Paint()..color = soft.withValues(alpha: .72);
    final rosePaint = Paint()..color = rose.withValues(alpha: .48);
    final goldPaint = Paint()..color = gold;
    final sagePaint = Paint()..color = sage.withValues(alpha: .72);
    switch (goal) {
      case UserGoal.cycle:
        final center = Offset(s * .5, s * .5);
        for (var i = 0; i < 6; i++) {
          canvas.save(); canvas.translate(center.dx, center.dy); canvas.rotate(2 * math.pi * i / 6);
          final petal = Path()..addOval(Rect.fromCenter(center: Offset(0, -s * .22), width: s * .18, height: s * .31));
          canvas.drawPath(petal, i.isEven ? rosePaint : shade); canvas.drawPath(petal, line); canvas.restore();
        }
        canvas.drawCircle(center, s * .07, goldPaint); canvas.drawCircle(center, s * .07, line);
        break;
      case UserGoal.conceive:
        // Deux mains qui soutiennent une jeune pousse : évite de supposer
        // que chaque personne a ou souhaite montrer un partenaire.
        final left = Path()..moveTo(s*.16,s*.65)..quadraticBezierTo(s*.22,s*.53,s*.36,s*.61)..quadraticBezierTo(s*.44,s*.68,s*.5,s*.66);
        final right = Path()..moveTo(s*.84,s*.65)..quadraticBezierTo(s*.78,s*.53,s*.64,s*.61)..quadraticBezierTo(s*.56,s*.68,s*.5,s*.66);
        canvas.drawPath(left, line); canvas.drawPath(right, line);
        final stem = Path()..moveTo(s*.5,s*.65)..quadraticBezierTo(s*.48,s*.43,s*.5,s*.27);
        canvas.drawPath(stem, Paint()..color=sage..style=PaintingStyle.stroke..strokeWidth=2.2..strokeCap=StrokeCap.round);
        final leaf1 = Path()..moveTo(s*.5,s*.45)..quadraticBezierTo(s*.28,s*.31,s*.31,s*.47)..quadraticBezierTo(s*.4,s*.55,s*.5,s*.45)..close();
        final leaf2 = Path()..moveTo(s*.5,s*.37)..quadraticBezierTo(s*.71,s*.22,s*.69,s*.4)..quadraticBezierTo(s*.6,s*.48,s*.5,s*.37)..close();
        canvas.drawPath(leaf1,sagePaint); canvas.drawPath(leaf1,line); canvas.drawPath(leaf2,sagePaint); canvas.drawPath(leaf2,line);
        break;
      case UserGoal.pregnancy:
        // Silhouette douce d’une personne, sans détail clinique.
        canvas.drawCircle(Offset(s*.48,s*.22),s*.1,rosePaint); canvas.drawCircle(Offset(s*.48,s*.22),s*.1,line);
        final body = Path()..moveTo(s*.42,s*.34)..quadraticBezierTo(s*.29,s*.46,s*.34,s*.67)..quadraticBezierTo(s*.37,s*.78,s*.51,s*.78)..quadraticBezierTo(s*.75,s*.78,s*.7,s*.57)..quadraticBezierTo(s*.68,s*.43,s*.56,s*.35)..close();
        canvas.drawPath(body,shade); canvas.drawPath(body,line);
        canvas.drawCircle(Offset(s*.62,s*.59),s*.125,rosePaint); canvas.drawCircle(Offset(s*.62,s*.59),s*.125,line);
        canvas.drawPath(Path()..moveTo(s*.44,s*.48)..quadraticBezierTo(s*.49,s*.59,s*.59,s*.62),line);
        canvas.drawPath(Path()..moveTo(s*.39,s*.77)..lineTo(s*.34,s*.89)..moveTo(s*.59,s*.78)..lineTo(s*.65,s*.89),line);
        break;
      case UserGoal.understand:
        final book = RRect.fromRectAndRadius(Rect.fromLTWH(s*.17,s*.25,s*.66,s*.53),Radius.circular(s*.07));
        canvas.drawRRect(book,shade); canvas.drawRRect(book,line);
        canvas.drawLine(Offset(s*.5,s*.26),Offset(s*.5,s*.77),line);
        canvas.drawLine(Offset(s*.26,s*.4),Offset(s*.43,s*.4),line);
        canvas.drawLine(Offset(s*.57,s*.4),Offset(s*.75,s*.4),line);
        canvas.drawLine(Offset(s*.26,s*.5),Offset(s*.41,s*.5),line);
        canvas.drawLine(Offset(s*.58,s*.5),Offset(s*.74,s*.5),line);
        final sprout = Path()..moveTo(s*.5,s*.26)..quadraticBezierTo(s*.45,s*.11,s*.34,s*.13)..quadraticBezierTo(s*.36,s*.28,s*.5,s*.28)..close();
        canvas.drawPath(sprout,sagePaint); canvas.drawPath(sprout,line);
        final sprout2 = Path()..moveTo(s*.5,s*.25)..quadraticBezierTo(s*.56,s*.1,s*.68,s*.12)..quadraticBezierTo(s*.64,s*.27,s*.5,s*.27)..close();
        canvas.drawPath(sprout2,sagePaint); canvas.drawPath(sprout2,line);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _GoalPainter oldDelegate) => oldDelegate.goal != goal || oldDelegate.rose != rose || oldDelegate.soft != soft;
}

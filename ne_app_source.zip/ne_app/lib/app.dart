import 'package:flutter/material.dart';

import 'app_controller.dart';
import 'core/app_theme.dart';
import 'screens/main_shell.dart';
import 'screens/onboarding_screen.dart';

class NeApp extends StatelessWidget {
  const NeApp({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return MaterialApp(
            title: 'Né',
            debugShowCheckedModeBanner: false,
            theme: NeTheme.light(),
            darkTheme: NeTheme.dark(),
            themeMode: controller.themeMode,
            home: !controller.ready
                ? const _LoadingScreen()
                : controller.lastError.isNotEmpty
                    ? _RecoveryScreen(controller: controller)
                    : controller.onboardingComplete
                        ? MainShell(controller: controller)
                        : OnboardingScreen(controller: controller),
          );
        },
      );
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();
  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
}

class _RecoveryScreen extends StatelessWidget {
  const _RecoveryScreen({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.lock_reset_rounded, size: 48, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(height: 18),
                    Text('Impossible d’ouvrir les données locales', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    Text(controller.lastError, textAlign: TextAlign.center),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: () async {
                        await controller.eraseAllData();
                      },
                      child: const Text('Réinitialiser les données locales'),
                    ),
                    const SizedBox(height: 8),
                    Text('Cette action efface les données Né présentes sur ce téléphone.', style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

enum ReliabilityLevel { insufficient, low, medium, high }

extension ReliabilityLabel on ReliabilityLevel {
  String get label => switch (this) {
        ReliabilityLevel.insufficient => 'Pas assez de données',
        ReliabilityLevel.low => 'Fiabilité basse',
        ReliabilityLevel.medium => 'Fiabilité moyenne',
        ReliabilityLevel.high => 'Fiabilité haute',
      };
}

class CyclePrediction {
  const CyclePrediction({
    required this.nextPeriodStart,
    required this.periodLength,
    required this.averageCycleLength,
    required this.standardDeviation,
    required this.sampleCount,
    required this.cycleDay,
    required this.reliability,
    required this.fertilityWindowStart,
    required this.fertilityWindowEnd,
    required this.ovulationDate,
  });

  final DateTime nextPeriodStart;
  final int periodLength;
  final int averageCycleLength;
  final double standardDeviation;
  final int sampleCount;
  final int cycleDay;
  final ReliabilityLevel reliability;
  final DateTime fertilityWindowStart;
  final DateTime fertilityWindowEnd;
  final DateTime ovulationDate;
}

class ArticleModel {
  const ArticleModel({
    required this.id,
    required this.title,
    required this.category,
    required this.readingMinutes,
    required this.summary,
    required this.body,
  });

  final String id;
  final String title;
  final String category;
  final int readingMinutes;
  final String summary;
  final String body;

  factory ArticleModel.fromMap(Map<String, dynamic> map) => ArticleModel(
        id: map['id'] as String,
        title: map['title'] as String,
        category: map['category'] as String,
        readingMinutes: map['readingMinutes'] as int,
        summary: map['summary'] as String,
        body: map['body'] as String,
      );
}

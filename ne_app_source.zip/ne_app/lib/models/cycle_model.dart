class CycleRecord {
  const CycleRecord({
    this.id,
    required this.startDate,
    required this.cycleLength,
    required this.periodLength,
    this.notes = '',
  });

  final int? id;
  final DateTime startDate;
  final int cycleLength;
  final int periodLength;
  final String notes;

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'start_date': _dateKey(startDate),
        'cycle_length': cycleLength,
        'period_length': periodLength,
        'notes': notes,
      };

  factory CycleRecord.fromMap(Map<String, Object?> map) => CycleRecord(
        id: map['id'] as int?,
        startDate: DateTime.parse(map['start_date']! as String),
        cycleLength: map['cycle_length']! as int,
        periodLength: map['period_length']! as int,
        notes: (map['notes'] as String?) ?? '',
      );

  static String _dateKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

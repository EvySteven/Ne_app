class AppointmentRecord {
  const AppointmentRecord({
    this.id,
    required this.title,
    required this.dateTime,
    this.place = '',
    this.reminderMinutes = 60,
    this.notes = '',
  });

  final int? id;
  final String title;
  final DateTime dateTime;
  final String place;
  final int reminderMinutes;
  final String notes;

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'title': title,
        'date_time': dateTime.toIso8601String(),
        'place': place,
        'reminder_minutes': reminderMinutes,
        'notes': notes,
      };

  factory AppointmentRecord.fromMap(Map<String, Object?> map) =>
      AppointmentRecord(
        id: map['id'] as int?,
        title: map['title']! as String,
        dateTime: DateTime.parse(map['date_time']! as String),
        place: (map['place'] as String?) ?? '',
        reminderMinutes: (map['reminder_minutes'] as int?) ?? 60,
        notes: (map['notes'] as String?) ?? '',
      );
}

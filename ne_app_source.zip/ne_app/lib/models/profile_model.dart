enum UserGoal { cycle, conceive, pregnancy, understand }

extension UserGoalText on UserGoal {
  String get label => switch (this) {
        UserGoal.cycle => 'Suivre mes règles',
        UserGoal.conceive => 'Tomber enceinte',
        UserGoal.pregnancy => 'Suivre ma grossesse',
        UserGoal.understand => 'Comprendre mon corps',
      };

  String get storageValue => name;

  static UserGoal fromStorage(String? value) => UserGoal.values.firstWhere(
        (goal) => goal.name == value,
        orElse: () => UserGoal.cycle,
      );
}

class UserProfile {
  const UserProfile({
    required this.nickname,
    required this.goal,
    this.lastMenstrualPeriod,
    this.confirmedDueDate,
    this.dueDateConfirmed = false,
  });

  final String nickname;
  final UserGoal goal;
  final DateTime? lastMenstrualPeriod;
  final DateTime? confirmedDueDate;
  final bool dueDateConfirmed;

  UserProfile copyWith({
    String? nickname,
    UserGoal? goal,
    DateTime? lastMenstrualPeriod,
    bool clearLastMenstrualPeriod = false,
    DateTime? confirmedDueDate,
    bool clearDueDate = false,
    bool? dueDateConfirmed,
  }) =>
      UserProfile(
        nickname: nickname ?? this.nickname,
        goal: goal ?? this.goal,
        lastMenstrualPeriod: clearLastMenstrualPeriod
            ? null
            : lastMenstrualPeriod ?? this.lastMenstrualPeriod,
        confirmedDueDate: clearDueDate
            ? null
            : confirmedDueDate ?? this.confirmedDueDate,
        dueDateConfirmed: dueDateConfirmed ?? this.dueDateConfirmed,
      );

  Map<String, Object?> toMap() => {
        'id': 1,
        'nickname': nickname,
        'goal': goal.storageValue,
        'last_menstrual_period': _dateKey(lastMenstrualPeriod),
        'due_date': _dateKey(confirmedDueDate),
        'due_date_confirmed': dueDateConfirmed ? 1 : 0,
      };

  factory UserProfile.fromMap(Map<String, Object?> map) => UserProfile(
        nickname: (map['nickname'] as String?) ?? '',
        goal: UserGoalText.fromStorage(map['goal'] as String?),
        lastMenstrualPeriod: _parseDate(map['last_menstrual_period'] as String?),
        confirmedDueDate: _parseDate(map['due_date'] as String?),
        dueDateConfirmed: (map['due_date_confirmed'] as int? ?? 0) == 1,
      );

  static DateTime? _parseDate(String? value) =>
      value == null || value.isEmpty ? null : DateTime.tryParse(value);

  static String? _dateKey(DateTime? d) => d == null
      ? null
      : '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

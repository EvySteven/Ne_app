import 'package:flutter/material.dart';

import '../app_controller.dart';
import 'anoushka_screen.dart';
import 'articles_screen.dart';
import 'calendar_screen.dart';
import 'home_screen.dart';
import 'profile_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.controller});
  final AppController controller;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selected = 0;

  String get _title => switch (_selected) {
        0 => widget.controller.profile.nickname.isEmpty
            ? 'Né'
            : 'Bonjour, ${widget.controller.profile.nickname}',
        1 => 'Mon calendrier',
        2 => 'Apprendre',
        _ => 'Anoushka',
      };

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _selected == 3 ? null : AppBar(
          title: Text(_title, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(
              tooltip: 'Mon profil et mes réglages',
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => ProfileScreen(controller: widget.controller),
                ),
              ),
              icon: const Icon(Icons.account_circle_outlined),
            ),
            const SizedBox(width: 5),
          ],
        ),
        body: SafeArea(
          top: false,
          child: IndexedStack(
            index: _selected,
            children: [
              HomeScreen(controller: widget.controller),
              CalendarScreen(controller: widget.controller),
              const ArticlesScreen(),
              const AnoushkaScreen(),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _selected,
          onDestinationSelected: (value) => setState(() => _selected = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Accueil'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month_rounded), label: 'Calendrier'),
            NavigationDestination(icon: Icon(Icons.auto_stories_outlined), selectedIcon: Icon(Icons.auto_stories_rounded), label: 'Articles'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: 'Anoushka'),
          ],
        ),
      );
}

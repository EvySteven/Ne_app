import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_controller.dart';
import '../models/profile_model.dart';
import '../widgets/handdrawn_illustrations.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  late final AnimationController _bloom;
  late final AnimationController _hold;
  final TextEditingController _nickname = TextEditingController();
  UserGoal? _goal;
  int _step = 0;
  bool _completed = false;

  bool get _sensitive =>
      _goal == UserGoal.conceive || _goal == UserGoal.pregnancy;

  @override
  void initState() {
    super.initState();
    _bloom = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..forward();
    _hold = AnimationController(vsync: this, duration: const Duration(seconds: 2));
    _hold.addStatusListener((status) {
      if (status == AnimationStatus.completed && mounted && !_completed) {
        _completed = true;
        HapticFeedback.mediumImpact();
        setState(() => _step = 5);
      }
    });
  }

  @override
  void dispose() {
    _bloom.dispose();
    _hold.dispose();
    _nickname.dispose();
    super.dispose();
  }

  void _back() {
    if (_step == 0) return;
    setState(() {
      if (_step == 5) {
        _step = 4;
        _completed = false;
      } else if (_step == 4) {
        _step = 3;
      } else if (_step == 3 && _sensitive) {
        _step = 2;
      } else {
        _step = _step - 1;
      }
    });
    _bloom.forward(from: 0);
  }

  void _chooseGoal(UserGoal value) {
    setState(() => _goal = value);
    HapticFeedback.selectionClick();
  }

  void _continueGoal() {
    if (_goal == null) return;
    setState(() => _step = _sensitive ? 2 : 3);
    _bloom.forward(from: 0);
  }

  void _continueFromWarning() {
    setState(() => _step = 3);
    _bloom.forward(from: 0);
  }

  void _continueFromNickname() {
    FocusScope.of(context).unfocus();
    setState(() => _step = 4);
    _bloom.forward(from: 0);
  }

  Future<void> _finish() async {
    await widget.controller.finishOnboarding(
      nickname: _nickname.text,
      goal: _goal ?? UserGoal.cycle,
    );
  }

  void _languageUnavailable(String label) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('La traduction $label doit être relue avant activation. Le français reste sélectionné pour cette version.')),
    );
  }

  String get _promise => switch (_goal ?? UserGoal.cycle) {
        UserGoal.cycle => 'Je prends le temps d’écouter mon corps et d’apprendre son rythme.',
        UserGoal.conceive => 'J’avance à mon rythme, avec des repères et des informations fiables.',
        UserGoal.pregnancy => 'Je prends soin de moi et je prépare mes questions pour mon suivi.',
        UserGoal.understand => 'Je m’informe et je découvre mon corps, pas à pas.',
      };

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.of(context).disableAnimations;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
              child: Row(
                children: [
                  if (_step > 0)
                    IconButton(onPressed: _back, tooltip: 'Retour', icon: const Icon(Icons.arrow_back_rounded))
                  else
                    const SizedBox(width: 48),
                  Expanded(
                    child: Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(5, (index) {
                          final active = index <= _step.clamp(0, 4);
                          return AnimatedContainer(
                            duration: reduceMotion ? Duration.zero : const Duration(milliseconds: 250),
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            width: active ? 22 : 7,
                            height: 7,
                            decoration: BoxDecoration(
                              color: active ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outline,
                              borderRadius: BorderRadius.circular(8),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
            ),
            Expanded(
              child: AnimatedSwitcher(
                duration: reduceMotion ? Duration.zero : const Duration(milliseconds: 280),
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(begin: const Offset(.025, .02), end: Offset.zero).animate(animation),
                    child: child,
                  ),
                ),
                child: _buildStep(context, key: ValueKey(_step)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep(BuildContext context, {required Key key}) {
    switch (_step) {
      case 0:
        return _welcome(key);
      case 1:
        return _goalPicker(key);
      case 2:
        return _warning(key);
      case 3:
        return _nicknamePage(key);
      case 4:
        return _commitment(key);
      default:
        return _languagePage(key);
    }
  }

  Widget _welcome(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(26, 18, 26, 24),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Text('Né', style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontSize: 42, color: Theme.of(context).colorScheme.primary)),
            Text('pour elle · par elle', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 28),
            AnimatedBuilder(
              animation: _bloom,
              builder: (context, _) => BloomingFlower(progress: Curves.easeOutBack.transform(_bloom.value), size: 210),
            ),
            const SizedBox(height: 10),
            Text('Bienvenue sur Né', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text('Un espace doux pour mieux connaître ton corps, suivre tes repères et trouver des informations utiles.', style: Theme.of(context).textTheme.bodyLarge, textAlign: TextAlign.center),
            const SizedBox(height: 11),
            Text('Tes données de cycle et de grossesse restent sur ce téléphone. Seule une question envoyée à Anoushka après ton accord est transmise au serveur; ton profil et tes dates ne sont pas ajoutés.', style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
            const SizedBox(height: 25),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () { setState(() => _step = 1); _bloom.forward(from: 0); }, icon: const Icon(Icons.spa_outlined), label: const Text('Commencer'))),
          ],
        ),
      );

  Widget _goalPicker(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(22, 25, 22, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Que souhaites-tu suivre ?', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('Choisis le parcours qui te correspond. Tu pourras changer ton objectif dans ton profil.', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 22),
            GridView.count(
              crossAxisCount: 2,
              mainAxisSpacing: 11,
              crossAxisSpacing: 11,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: .91,
              children: UserGoal.values.map((goal) {
                final selected = _goal == goal;
                return Semantics(
                  button: true,
                  selected: selected,
                  label: goal.label,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () => _chooseGoal(goal),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: selected ? Theme.of(context).colorScheme.secondary.withValues(alpha: .35) : Theme.of(context).colorScheme.surface,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outline, width: selected ? 2 : 1),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          GoalIllustration(goal: goal, size: 66),
                          const SizedBox(height: 9),
                          Text(goal.label, textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelLarge),
                          const SizedBox(height: 4),
                          Text(_goalSubtitle(goal), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 9)),
                          if (selected) Icon(Icons.check_circle_rounded, color: Theme.of(context).colorScheme.primary, size: 17),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _goal == null ? null : _continueGoal, child: const Text('Suivant'))),
          ],
        ),
      );

  String _goalSubtitle(UserGoal goal) => switch (goal) {
        UserGoal.cycle => 'Mes règles et mon calendrier',
        UserGoal.conceive => 'Mes repères de fertilité',
        UserGoal.pregnancy => 'Ma grossesse, semaine après semaine',
        UserGoal.understand => 'Des articles pour apprendre',
      };

  Widget _warning(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(24, 40, 24, 24),
        child: Column(
          children: [
            Container(width: 74, height: 74, decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondary.withValues(alpha: .4), shape: BoxShape.circle), child: Icon(Icons.favorite_border_rounded, size: 34, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(height: 22),
            Text('Avant de continuer', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text('Certains contenus liés à la fertilité ou à la grossesse peuvent aborder des sujets sensibles. Tu peux les consulter, les passer ou revenir plus tard. C’est toujours ton choix.', style: Theme.of(context).textTheme.bodyLarge, textAlign: TextAlign.center),
            const SizedBox(height: 26),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueFromWarning, child: const Text('Continuer'))),
            TextButton(onPressed: _continueFromWarning, child: const Text('Passer cette étape')),
          ],
        ),
      );

  Widget _nicknamePage(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(24, 42, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: BloomingFlower(progress: _bloom.value, size: 100)),
            const SizedBox(height: 20),
            Text('Comment souhaites-tu être appelée ?', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
            const SizedBox(height: 9),
            Text('Tu peux choisir un pseudo ou laisser ce champ vide. Il reste enregistré uniquement sur ce téléphone.', style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
            const SizedBox(height: 24),
            TextField(controller: _nickname, maxLength: 30, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Ton pseudo (facultatif)', prefixIcon: Icon(Icons.person_outline_rounded))),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _continueFromNickname, child: const Text('Continuer'))),
            Center(child: TextButton(onPressed: _continueFromNickname, child: const Text('Je préfère ne pas en mettre'))),
          ],
        ),
      );

  Widget _commitment(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(24, 27, 24, 24),
        child: Column(
          children: [
            Text('Un petit engagement envers toi', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text(_promise, style: Theme.of(context).textTheme.bodyLarge, textAlign: TextAlign.center),
            const SizedBox(height: 30),
            SizedBox(
              width: 210,
              height: 210,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _hold,
                    builder: (context, _) => SizedBox.expand(child: CircularProgressIndicator(value: _hold.value, strokeWidth: 7, backgroundColor: Theme.of(context).colorScheme.secondary.withValues(alpha: .35), color: Theme.of(context).colorScheme.primary, strokeCap: StrokeCap.round)),
                  ),
                  GestureDetector(
                    onLongPressStart: (_) { _completed = false; _hold.forward(from: 0); HapticFeedback.selectionClick(); },
                    onLongPressEnd: (_) { if (_hold.value < 1) _hold.reverse(); },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 176,
                      height: 176,
                      decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Theme.of(context).colorScheme.primary.withValues(alpha: .22), blurRadius: 20, spreadRadius: 2)]),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          BloomingFlower(progress: .55 + .45 * _hold.value, size: 78),
                          const SizedBox(height: 3),
                          Text(_hold.value > .65 ? 'Je prends soin de moi…' : 'Maintiens 2 secondes', textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: Colors.white, fontSize: 11)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('Tu peux aussi passer cette étape.', style: Theme.of(context).textTheme.bodySmall),
            TextButton(onPressed: () { _hold.stop(); setState(() => _step = 5); }, child: const Text('Passer')),
          ],
        ),
      );

  Widget _languagePage(Key key) => SingleChildScrollView(
        key: key,
        padding: const EdgeInsets.fromLTRB(24, 35, 24, 24),
        child: Column(
          children: [
            const BloomingFlower(progress: 1, size: 92),
            const SizedBox(height: 14),
            Text('Dans quelle langue ?', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text('Le français est prêt dans cette version. Les traductions Mooré et Dioula seront activées après validation par des locuteurs.', style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
            const SizedBox(height: 22),
            _languageTile('Français', 'fr', enabled: true),
            const SizedBox(height: 9),
            _languageTile('Mooré', 'moore', enabled: false),
            const SizedBox(height: 9),
            _languageTile('Dioula', 'dioula', enabled: false),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _finish, child: const Text('Entrer dans Né'))),
            const SizedBox(height: 10),
            Text('Tu pourras modifier tes préférences dans ton profil.', style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
          ],
        ),
      );

  Widget _languageTile(String label, String code, {required bool enabled}) {
    final selected = code == 'fr';
    return InkWell(
      onTap: enabled ? null : () => _languageUnavailable(label),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
        decoration: BoxDecoration(
          border: Border.all(color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outline),
          borderRadius: BorderRadius.circular(16),
          color: selected ? Theme.of(context).colorScheme.secondary.withValues(alpha: .25) : Theme.of(context).colorScheme.surface,
        ),
        child: Row(children: [Icon(selected ? Icons.check_circle : enabled ? Icons.language : Icons.hourglass_bottom_rounded, color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.onSurfaceVariant, size: 19), const SizedBox(width: 10), Expanded(child: Text(label, style: Theme.of(context).textTheme.labelLarge)), if (!enabled) Text('À valider', style: Theme.of(context).textTheme.bodySmall)]),
      ),
    );
  }
}

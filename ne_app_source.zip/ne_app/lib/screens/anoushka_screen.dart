import 'package:flutter/material.dart';

import '../services/anoushka_client.dart';

class AnoushkaScreen extends StatefulWidget {
  const AnoushkaScreen({super.key});

  @override
  State<AnoushkaScreen> createState() => _AnoushkaScreenState();
}

class _AnoushkaScreenState extends State<AnoushkaScreen> {
  final AnoushkaClient _client = AnoushkaClient();
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<_ChatMessage> _messages = [
    const _ChatMessage(
      text: 'Bonjour, je suis Anoushka, une intelligence artificielle. Je peux proposer des informations générales, mais je ne suis pas une professionnelle de santé et je ne pose pas de diagnostic.',
      fromAssistant: true,
    ),
  ];
  late String _sessionId;
  bool _consentedForSession = false;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _sessionId = AnoushkaClient.createEphemeralSessionId();
  }

  @override
  void dispose() {
    _client.close();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<bool> _requestConsent() async {
    if (_consentedForSession) return true;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Avant d’écrire à Anoushka'),
        content: const SingleChildScrollView(
          child: Text(
            'Anoushka est une IA. Si tu continues, le texte de ta question sera envoyé par Internet à anoushka.onrender.com et traité par les services utilisés par ce serveur. Un identifiant de session aléatoire sera transmis pour relier les échanges de cette conversation.\n\nTon pseudo, tes dates de cycle, ta grossesse et tes rendez-vous ne sont pas ajoutés à l’envoi. La conversation reste en mémoire sur cette page uniquement, mais le serveur ou ses fournisseurs peuvent appliquer leurs propres règles de conservation. N’écris pas ton nom, ton numéro de téléphone ou une information qui t’identifie.\n\nAnoushka fournit des renseignements généraux, pas un diagnostic ni un avis médical personnalisé. En cas de souci de santé, contacte un professionnel de santé.',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Pas maintenant')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('J’accepte et je continue')),
        ],
      ),
    );
    _consentedForSession = accepted ?? false;
    return _consentedForSession;
  }

  Future<void> _send() async {
    final question = _input.text.trim();
    if (question.isEmpty || _sending) return;
    final consented = await _requestConsent();
    if (!mounted || !consented) return;
    _input.clear();
    setState(() {
      _messages.add(_ChatMessage(text: question, fromAssistant: false));
      _sending = true;
    });
    _scrollToBottom();
    try {
      final reply = await _client.ask(question, _sessionId);
      if (!mounted) return;
      setState(() => _messages.add(_ChatMessage(
            text: reply.source == null || reply.source!.trim().isEmpty
                ? reply.text
                : '${reply.text}\n\nSource indiquée : ${reply.source}',
            fromAssistant: true,
          )));
    } catch (_) {
      if (!mounted) return;
      setState(() => _messages.add(const _ChatMessage(
            text: 'Je n’arrive pas à joindre le service pour le moment. Vérifie ta connexion et réessaie plus tard. Si ta question concerne un symptôme urgent, contacte directement un service de santé.',
            fromAssistant: true,
          )));
    } finally {
      if (mounted) {
        setState(() => _sending = false);
        _scrollToBottom();
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _clearConversation() {
    setState(() {
      _messages
        ..clear()
        ..add(const _ChatMessage(
          text: 'Nouvelle conversation. Je suis Anoushka, une intelligence artificielle. Je peux partager des informations générales, sans remplacer une professionnelle de santé.',
          fromAssistant: true,
        ));
      _consentedForSession = false;
      _sessionId = AnoushkaClient.createEphemeralSessionId();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 35, height: 35, decoration: BoxDecoration(color: theme.colorScheme.secondary.withValues(alpha: .4), shape: BoxShape.circle), child: Icon(Icons.auto_awesome_rounded, color: theme.colorScheme.primary, size: 20)),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Anoushka'),
            Text('Intelligence artificielle', style: theme.textTheme.bodySmall),
          ]),
        ]),
        actions: [
          IconButton(tooltip: 'Effacer cette conversation', onPressed: _sending ? null : _clearConversation, icon: const Icon(Icons.delete_outline_rounded)),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(12, 2, 12, 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: theme.colorScheme.secondary.withValues(alpha: .2), borderRadius: BorderRadius.circular(16)),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.info_outline_rounded, size: 18, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(child: Text('Tes questions sont envoyées à ${_client.configuredHost} uniquement après ton accord. La première réponse peut prendre jusqu’à une minute si le service est en veille. Ne partage pas d’informations identifiantes. Cette IA ne remplace pas un professionnel de santé.', style: theme.textTheme.bodySmall)),
              ]),
            ),
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
                itemCount: _messages.length + (_sending ? 1 : 0),
                itemBuilder: (context, index) {
                  if (_sending && index == _messages.length) {
                    return const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))));
                  }
                  return _bubble(context, _messages[index]);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    maxLength: 2000,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.newline,
                    decoration: const InputDecoration(hintText: 'Écris ta question…', counterText: '', prefixIcon: Icon(Icons.chat_bubble_outline_rounded)),
                  ),
                ),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: IconButton.filled(
                    tooltip: 'Envoyer à Anoushka',
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.arrow_upward_rounded),
                  ),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bubble(BuildContext context, _ChatMessage message) {
    final theme = Theme.of(context);
    final alignment = message.fromAssistant ? Alignment.centerLeft : Alignment.centerRight;
    final color = message.fromAssistant
        ? theme.colorScheme.surfaceContainerHighest
        : theme.colorScheme.primary;
    final textColor = message.fromAssistant
        ? theme.colorScheme.onSurface
        : theme.colorScheme.onPrimary;
    return Align(
      alignment: alignment,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 320),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(17),
            topRight: const Radius.circular(17),
            bottomLeft: Radius.circular(message.fromAssistant ? 5 : 17),
            bottomRight: Radius.circular(message.fromAssistant ? 17 : 5),
          ),
        ),
        child: Text(message.text, style: theme.textTheme.bodyMedium?.copyWith(color: textColor)),
      ),
    );
  }
}

class _ChatMessage {
  const _ChatMessage({required this.text, required this.fromAssistant});
  final String text;
  final bool fromAssistant;
}

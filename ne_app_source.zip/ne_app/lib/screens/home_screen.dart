import 'package:flutter/material.dart';

import '../app_controller.dart';
import '../core/formatters.dart';
import '../models/appointment_model.dart';
import '../models/cycle_model.dart';
import '../models/profile_model.dart';
import '../services/pregnancy_service.dart';
import 'pregnancy_week_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _welcomeCard(context),
            const SizedBox(height: 16),
            switch (controller.profile.goal) {
              UserGoal.pregnancy => _PregnancyDashboard(controller: controller),
              UserGoal.conceive => _ConceiveDashboard(controller: controller),
              UserGoal.understand => _UnderstandDashboard(controller: controller),
              UserGoal.cycle => _CycleDashboard(controller: controller),
            },
            if (controller.lastError.isNotEmpty) ...[
              const SizedBox(height: 12),
              _Notice(text: controller.lastError, icon: Icons.warning_amber_rounded),
            ],
          ],
        ),
      );

  Widget _welcomeCard(BuildContext context) {
    final nickname = controller.profile.nickname.trim();
    final greeting = nickname.isEmpty ? 'Ton espace, à ton rythme' : 'Bonjour, $nickname';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 18, 14, 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(23),
        gradient: LinearGradient(
          colors: [Theme.of(context).colorScheme.secondary.withValues(alpha: .55), Theme.of(context).colorScheme.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: Theme.of(context).colorScheme.outline),
      ),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(greeting, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 5),
          Text('Un petit pas à la fois, sans pression.', style: Theme.of(context).textTheme.bodyMedium),
        ])),
        const Icon(Icons.spa_rounded, size: 42),
      ]),
    );
  }
}

class _CycleDashboard extends StatelessWidget {
  const _CycleDashboard({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final prediction = controller.cyclePrediction;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeading(title: 'Mon cycle', subtitle: 'Des repères qui s’améliorent avec tes observations.'),
      const SizedBox(height: 12),
      if (prediction == null)
        _EmptyCard(
          icon: Icons.water_drop_outlined,
          title: 'Commence par noter tes règles',
          body: 'Ajoute une date de début et, si tu la connais, la durée habituelle de ton cycle. Né affichera toujours la fiabilité de ses estimations.',
          button: 'Enregistrer mes règles',
          onPressed: () => _showCycleForm(context, controller),
        )
      else ...[
        _CycleHero(prediction: prediction, conception: false),
        const SizedBox(height: 12),
        _ReliabilityCard(prediction: prediction),
        const SizedBox(height: 12),
        const _InfoCard(
          icon: Icons.info_outline_rounded,
          title: 'À garder en tête',
          body: 'Les dates sont des estimations fondées sur les cycles enregistrés. Elles ne prédisent pas avec certitude les règles ou l’ovulation et ne constituent pas une méthode contraceptive.',
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => _showCycleForm(context, controller), icon: const Icon(Icons.add), label: const Text('Enregistrer un nouveau début de règles')),
      ],
      const SizedBox(height: 12),
      const _PreferenceHint(text: 'Né ne remplace pas un avis médical. Tu peux choisir les rappels dans ton profil.'),
    ]);
  }
}

class _ConceiveDashboard extends StatelessWidget {
  const _ConceiveDashboard({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final prediction = controller.cyclePrediction;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeading(title: 'Mon parcours conception', subtitle: 'Des informations générales, sans promesse ni pression.'),
      const SizedBox(height: 12),
      if (prediction == null)
        _EmptyCard(icon: Icons.spa_outlined, title: 'Ajoute tes repères de cycle', body: 'Une estimation de fenêtre fertile ne devient utile qu’avec des observations, et reste incertaine. Tu peux commencer par noter tes règles.', button: 'Enregistrer mes règles', onPressed: () => _showCycleForm(context, controller))
      else ...[
        _CycleHero(prediction: prediction, conception: true),
        const SizedBox(height: 12),
        _ReliabilityCard(prediction: prediction),
        const SizedBox(height: 12),
        const _InfoCard(icon: Icons.favorite_border_rounded, title: 'La fenêtre fertile est une estimation', body: 'Elle est calculée à partir des cycles enregistrés et peut être imprécise, notamment si les cycles varient. Elle ne confirme pas une ovulation et ne doit pas être utilisée comme contraception.'),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => _showCycleForm(context, controller), icon: const Icon(Icons.add), label: const Text('Ajouter une date de règles')),
      ],
      const SizedBox(height: 12),
      const _InfoCard(icon: Icons.menu_book_outlined, title: 'Des informations utiles', body: 'La rubrique Articles explique le cycle, la fertilité et les limites des méthodes de calcul. Chaque parcours reste personnel.'),
    ]);
  }
}

class _UnderstandDashboard extends StatelessWidget {
  const _UnderstandDashboard({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionHeading(title: 'Découvrir et apprendre', subtitle: 'Des repères simples, à consulter à ton rythme.'),
        const SizedBox(height: 12),
        const _InfoCard(icon: Icons.auto_stories_outlined, title: 'Commence par les articles', body: 'Les contenus sont disponibles hors ligne. Ils sont encore en version de démonstration et devront être relus par des professionnels de santé avant diffusion.'),
        const SizedBox(height: 12),
        _EmptyCard(icon: Icons.calendar_today_outlined, title: 'Tu peux aussi suivre ton cycle', body: 'Le suivi est facultatif. Tes notes restent sur ce téléphone et les estimations indiquent clairement leur niveau de fiabilité.', button: controller.cycles.isEmpty ? 'Enregistrer une date' : 'Ajouter une date de règles', onPressed: () => _showCycleForm(context, controller)),
      ]);
}

class _PregnancyDashboard extends StatelessWidget {
  const _PregnancyDashboard({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final profile = controller.profile;
    final age = const PregnancyService().age(profile);
    final estimated = const PregnancyService().estimatedDueDate(profile.lastMenstrualPeriod);
    final due = profile.dueDateConfirmed && profile.confirmedDueDate != null
        ? profile.confirmedDueDate
        : (profile.confirmedDueDate ?? estimated);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionHeading(title: 'Ma grossesse', subtitle: 'Un suivi informatif semaine après semaine.'),
      const SizedBox(height: 12),
      if (age == null)
        _EmptyCard(icon: Icons.favorite_border_rounded, title: 'Ajoute une date de repère', body: profile.confirmedDueDate != null && !profile.dueDateConfirmed && profile.lastMenstrualPeriod == null ? 'La date prévue enregistrée (${formatDate(profile.confirmedDueDate!)}) n’est pas marquée comme confirmée. Pour calculer une semaine indicative, ajoute aussi la date de tes dernières règles ou confirme cette date avec un professionnel.' : 'Tu peux noter la date de tes dernières règles, une date prévue, ou les deux. Une date confirmée par un professionnel est utilisée en priorité.', button: 'Configurer mon suivi', onPressed: () => _showPregnancyForm(context, controller))
      else ...[
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondary.withValues(alpha: .35),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Theme.of(context).colorScheme.outline),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(age.isWithinSupportedRange ? 'Semaine ${age.weeks}' : 'Date à vérifier', style: Theme.of(context).textTheme.headlineMedium)),
              const Icon(Icons.spa_outlined, size: 32),
            ]),
            const SizedBox(height: 5),
            Text(age.isWithinSupportedRange ? '${age.days} jour${age.days == 1 ? '' : 's'} dans cette semaine' : 'Les dates enregistrées se situent hors de la plage affichée par Né. Mets-les à jour avec l’aide d’un professionnel de santé.', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 12),
            Text(age.sourceLabel, style: Theme.of(context).textTheme.bodySmall),
            if (due != null) ...[
              const SizedBox(height: 8),
              Row(children: [const Icon(Icons.event_available_outlined, size: 17), const SizedBox(width: 7), Expanded(child: Text('Date prévue : ${formatDate(due)}${profile.dueDateConfirmed ? ' · confirmée' : ' · estimation'}', style: Theme.of(context).textTheme.labelLarge))]),
            ],
            const SizedBox(height: 14),
            OutlinedButton.icon(onPressed: () => _showPregnancyForm(context, controller), icon: const Icon(Icons.edit_calendar_outlined), label: const Text('Modifier mes dates')),
          ]),
        ),
        const SizedBox(height: 12),
        const _InfoCard(icon: Icons.health_and_safety_outlined, title: 'Ton suivi professionnel reste prioritaire', body: 'Né présente des repères calendaires. Ils ne remplacent pas les consultations, échographies ni les conseils de l’équipe qui suit ta grossesse.'),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => PregnancyWeekScreen(currentWeek: age.weeks))), icon: const Icon(Icons.view_week_outlined), label: const Text('Ouvrir le suivi semaine par semaine'))),
      ],
      const SizedBox(height: 18),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Mes rendez-vous', style: Theme.of(context).textTheme.titleLarge),
        TextButton.icon(onPressed: () => _showAppointmentForm(context, controller), icon: const Icon(Icons.add, size: 18), label: const Text('Ajouter')),
      ]),
      if (controller.appointments.isEmpty)
        const _InfoCard(icon: Icons.notifications_active_outlined, title: 'Garde tes dates importantes', body: 'Ajoute un rendez-vous pour l’enregistrer localement et, si tu actives les notifications, recevoir un rappel discret.')
      else
        ...controller.appointments.where((a) => a.dateTime.isAfter(DateTime.now().subtract(const Duration(days: 1)))).take(5).map((appointment) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: _AppointmentTile(appointment: appointment, onDelete: () => controller.deleteAppointment(appointment)),
            )),
      if (age != null) ...[
        const SizedBox(height: 12),
        const _InfoCard(icon: Icons.menu_book_outlined, title: 'Les articles grossesse', body: 'Retrouve des repères généraux dans Articles. Les contenus de cette version sont démonstratifs et doivent être validés par des professionnels avant publication.'),
      ],
    ]);
  }
}

class _CycleHero extends StatelessWidget {
  const _CycleHero({required this.prediction, required this.conception});
  final CyclePredictionView prediction;
  final bool conception;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(23)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(conception ? 'Fenêtre fertile estimée' : 'Ton cycle aujourd’hui', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onPrimary)),
          const SizedBox(height: 8),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(child: Text(conception ? '${formatShortDate(prediction.fertilityStart)} – ${formatShortDate(prediction.fertilityEnd)}' : 'Jour ${prediction.cycleDay}', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Theme.of(context).colorScheme.onPrimary, fontSize: conception ? 25 : 34))),
            Icon(conception ? Icons.eco_outlined : Icons.water_drop_outlined, color: Theme.of(context).colorScheme.onPrimary, size: 38),
          ]),
          const SizedBox(height: 13),
          Divider(color: Theme.of(context).colorScheme.onPrimary.withValues(alpha: .35)),
          const SizedBox(height: 6),
          Text(conception ? 'Ovulation estimée : ${formatShortDate(prediction.ovulation)}' : 'Prochain début estimé : ${formatDate(prediction.nextPeriodStart)}', style: Theme.of(context).textTheme.labelLarge?.copyWith(color: Theme.of(context).colorScheme.onPrimary)),
          const SizedBox(height: 4),
          Text('Cycle de référence : environ ${prediction.cycleLength} jours · règles notées : ${prediction.periodLength} jours en moyenne', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onPrimary.withValues(alpha: .86))),
        ]),
      );
}

class _ReliabilityCard extends StatelessWidget {
  const _ReliabilityCard({required this.prediction});
  final CyclePredictionView prediction;

  @override
  Widget build(BuildContext context) {
    final low = prediction.sampleCount < 3;
    final icon = low ? Icons.info_outline_rounded : Icons.analytics_outlined;
    return _InfoCard(
      icon: icon,
      title: prediction.reliabilityLabel,
      body: low
          ? prediction.sampleCount == 0
              ? 'Aucun intervalle complet n’est encore mesuré. Cette première date est un repère provisoire basé sur la durée habituelle choisie.'
              : 'Né a mesuré ${prediction.sampleCount} intervalle${prediction.sampleCount == 1 ? '' : 's'} entre des dates de début. Il faut au moins 3 cycles complets (4 dates de début) pour commencer à estimer la fiabilité.'
          : 'Estimation calculée à partir de ${prediction.sampleCount} intervalles réellement observés entre les débuts de règles. Les variations d’un mois à l’autre peuvent modifier la date réelle.',
    );
  }
}

class _AppointmentTile extends StatelessWidget {
  const _AppointmentTile({required this.appointment, required this.onDelete});
  final AppointmentRecord appointment;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.secondary.withValues(alpha: .35), child: Icon(Icons.event_note_outlined, color: Theme.of(context).colorScheme.primary)),
          title: Text(appointment.title, style: Theme.of(context).textTheme.titleMedium),
          subtitle: Text('${formatDateTime(appointment.dateTime)}${appointment.place.isEmpty ? '' : '\n${appointment.place}'}', maxLines: 2),
          isThreeLine: appointment.place.isNotEmpty,
          trailing: IconButton(tooltip: 'Supprimer le rendez-vous', onPressed: onDelete, icon: const Icon(Icons.delete_outline_rounded)),
        ),
      );
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.icon, required this.title, required this.body, required this.button, required this.onPressed});
  final IconData icon;
  final String title;
  final String body;
  final String button;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 28, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 7),
            Text(body, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 14),
            FilledButton.tonalIcon(onPressed: onPressed, icon: const Icon(Icons.arrow_forward_rounded), label: Text(button)),
          ]),
        ),
      );
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.body});
  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary, size: 22),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 5), Text(body, style: Theme.of(context).textTheme.bodySmall)])),
          ]),
        ),
      );
}

class _Notice extends StatelessWidget {
  const _Notice({required this.text, required this.icon});
  final String text;
  final IconData icon;
  @override
  Widget build(BuildContext context) => _InfoCard(icon: icon, title: 'À vérifier', body: text);
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.headlineMedium), const SizedBox(height: 3), Text(subtitle, style: Theme.of(context).textTheme.bodySmall)]);
}

class _PreferenceHint extends StatelessWidget {
  const _PreferenceHint({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Text(text, style: Theme.of(context).textTheme.bodySmall);
}

Future<void> _showCycleForm(BuildContext context, AppController controller) async {
  DateTime start = DateTime.now();
  int cycleLength = 28;
  int periodLength = 5;
  final notes = TextEditingController();
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (context) => StatefulBuilder(builder: (context, setModalState) => Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Enregistrer des règles', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 6),
        Text('Dès que plusieurs dates sont notées, Né mesure les intervalles réels entre les débuts. La durée habituelle sert seulement de repère provisoire avec une seule date.', style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 15),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_today_outlined), title: const Text('Premier jour des règles'), subtitle: Text(formatDate(start)), onTap: () async {
          final picked = await showDatePicker(context: context, initialDate: start, firstDate: DateTime(1990), lastDate: DateTime.now().add(const Duration(days: 1)), helpText: 'Choisir le premier jour');
          if (picked != null) setModalState(() => start = picked);
        }),
        DropdownButtonFormField<int>(initialValue: cycleLength, decoration: const InputDecoration(labelText: 'Durée habituelle (repère initial)'), items: List.generate(46, (i) => i + 15).map((d) => DropdownMenuItem(value: d, child: Text('$d jours'))).toList(), onChanged: (value) { if (value != null) setModalState(() => cycleLength = value); }),
        const SizedBox(height: 10),
        DropdownButtonFormField<int>(initialValue: periodLength, decoration: const InputDecoration(labelText: 'Durée des règles (si connue)'), items: List.generate(15, (i) => i + 1).map((d) => DropdownMenuItem(value: d, child: Text('$d jours'))).toList(), onChanged: (value) { if (value != null) setModalState(() => periodLength = value); }),
        const SizedBox(height: 10),
        TextField(controller: notes, maxLines: 2, maxLength: 250, decoration: const InputDecoration(labelText: 'Note facultative (stockée localement)', prefixIcon: Icon(Icons.edit_note_rounded))),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async {
          try {
            await controller.saveCycle(CycleRecord(startDate: start, cycleLength: cycleLength, periodLength: periodLength, notes: notes.text.trim()));
            if (context.mounted) Navigator.pop(context);
          } catch (_) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cette date existe déjà ou les données n’ont pas pu être enregistrées.')));
          }
        }, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer'))),
      ])),
    )),
  );
  notes.dispose();
}

Future<void> _showPregnancyForm(BuildContext context, AppController controller) async {
  DateTime? lmp = controller.profile.lastMenstrualPeriod;
  DateTime? due = controller.profile.confirmedDueDate;
  bool confirmed = controller.profile.dueDateConfirmed;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (context) => StatefulBuilder(builder: (context, setModalState) => Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Mes dates de grossesse', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 7),
        Text('Une date prévue confirmée par un professionnel est prioritaire sur le calcul à partir des dernières règles.', style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 13),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.water_drop_outlined), title: const Text('Date des dernières règles (facultatif)'), subtitle: Text(formatDate(lmp)), trailing: IconButton(tooltip: 'Effacer', onPressed: lmp == null ? null : () => setModalState(() => lmp = null), icon: const Icon(Icons.close_rounded)), onTap: () async {
          final today = DateTime.now();
          final picked = await showDatePicker(context: context, initialDate: lmp ?? today.subtract(const Duration(days: 60)), firstDate: DateTime(1990), lastDate: today, helpText: 'Choisir la date');
          if (picked != null) setModalState(() => lmp = picked);
        }),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event_available_outlined), title: const Text('Date prévue d’accouchement (facultatif)'), subtitle: Text(formatDate(due)), trailing: IconButton(tooltip: 'Effacer', onPressed: due == null ? null : () => setModalState(() { due = null; confirmed = false; }), icon: const Icon(Icons.close_rounded)), onTap: () async {
          final today = DateTime.now();
          final picked = await showDatePicker(context: context, initialDate: due ?? today.add(const Duration(days: 160)), firstDate: today.subtract(const Duration(days: 300)), lastDate: today.add(const Duration(days: 300)), helpText: 'Choisir la date prévue');
          if (picked != null) setModalState(() => due = picked);
        }),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: confirmed && due != null, onChanged: due == null ? null : (value) => setModalState(() => confirmed = value), title: const Text('Date confirmée par un professionnel'), subtitle: const Text('Si activée, cette date est utilisée en priorité.'), secondary: const Icon(Icons.verified_outlined)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: () async {
          try {
            await controller.updateProfile(controller.profile.copyWith(
              lastMenstrualPeriod: lmp,
              clearLastMenstrualPeriod: lmp == null,
              confirmedDueDate: due,
              clearDueDate: due == null,
              dueDateConfirmed: confirmed && due != null,
            ));
            if (context.mounted) Navigator.pop(context);
          } catch (_) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Les dates n’ont pas pu être enregistrées.')));
          }
        }, child: const Text('Enregistrer mes dates'))),
        const SizedBox(height: 8),
        Text('Né présente un repère informatif et ne remplace pas les conseils de l’équipe de suivi.', style: Theme.of(context).textTheme.bodySmall),
      ])),
    )),
  );
}

Future<void> _showAppointmentForm(BuildContext context, AppController controller) async {
  final title = TextEditingController(text: 'Rendez-vous de suivi');
  final place = TextEditingController();
  final notes = TextEditingController();
  DateTime day = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 9, minute: 0);
  int reminder = 60;
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (context) => StatefulBuilder(builder: (context, setModalState) => Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Ajouter un rendez-vous', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 13),
        TextField(controller: title, maxLength: 80, decoration: const InputDecoration(labelText: 'Titre', prefixIcon: Icon(Icons.event_note_outlined))),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_month_outlined), title: const Text('Date'), subtitle: Text(formatDate(day)), onTap: () async {
          final picked = await showDatePicker(context: context, initialDate: day, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 1095)));
          if (picked != null) setModalState(() => day = picked);
        }),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.schedule_rounded), title: const Text('Heure'), subtitle: Text(time.format(context)), onTap: () async {
          final picked = await showTimePicker(context: context, initialTime: time);
          if (picked != null) setModalState(() => time = picked);
        }),
        TextField(controller: place, maxLength: 100, decoration: const InputDecoration(labelText: 'Lieu (facultatif)', prefixIcon: Icon(Icons.place_outlined))),
        DropdownButtonFormField<int>(initialValue: reminder, decoration: const InputDecoration(labelText: 'Me rappeler'), items: const [DropdownMenuItem(value: 0, child: Text('À l’heure du rendez-vous')), DropdownMenuItem(value: 60, child: Text('1 heure avant')), DropdownMenuItem(value: 1440, child: Text('1 jour avant'))], onChanged: (value) { if (value != null) setModalState(() => reminder = value); }),
        const SizedBox(height: 10),
        TextField(controller: notes, maxLines: 2, maxLength: 250, decoration: const InputDecoration(labelText: 'Questions ou note personnelle (facultatif)', prefixIcon: Icon(Icons.edit_note_rounded))),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: () async {
          if (title.text.trim().isEmpty) return;
          final dateTime = DateTime(day.year, day.month, day.day, time.hour, time.minute);
          try {
            await controller.addAppointment(AppointmentRecord(title: title.text.trim(), dateTime: dateTime, place: place.text.trim(), reminderMinutes: reminder, notes: notes.text.trim()));
            if (context.mounted) Navigator.pop(context);
          } catch (_) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Le rendez-vous n’a pas pu être enregistré.')));
          }
        }, child: const Text('Enregistrer le rendez-vous'))),
        const SizedBox(height: 7),
        Text('Les rappels restent locaux. Ils ne s’affichent que si tu as autorisé les notifications dans ton profil.', style: Theme.of(context).textTheme.bodySmall),
      ])),
    )),
  );
  title.dispose(); place.dispose(); notes.dispose();
}

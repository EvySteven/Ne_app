import 'package:flutter/material.dart';

class PregnancyWeekScreen extends StatefulWidget {
  const PregnancyWeekScreen({super.key, required this.currentWeek});
  final int currentWeek;

  @override
  State<PregnancyWeekScreen> createState() => _PregnancyWeekScreenState();
}

class _PregnancyWeekScreenState extends State<PregnancyWeekScreen> {
  late int _selectedWeek;

  @override
  void initState() {
    super.initState();
    _selectedWeek = widget.currentWeek.clamp(1, 42).toInt();
  }

  String get _stage => _selectedWeek <= 13
      ? 'Premier trimestre'
      : _selectedWeek <= 27
          ? 'Deuxième trimestre'
          : 'Troisième trimestre';

  String get _focus => _selectedWeek <= 13
      ? 'Note les questions que tu souhaites partager lors de ton prochain rendez-vous. Tu peux aussi ajouter une date importante dans ton calendrier.'
      : _selectedWeek <= 27
          ? 'Garde tes dates de rendez-vous à jour et note les sujets dont tu souhaites parler avec l’équipe qui suit ta grossesse.'
          : 'Vérifie les prochains rendez-vous et prépare les questions que tu souhaites aborder avec ton équipe de suivi.';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Suivi semaine par semaine')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
        children: [
          Text('Choisis une semaine', style: theme.textTheme.titleLarge),
          const SizedBox(height: 4),
          Text('La semaine actuelle est mise en avant; tu peux consulter les autres repères du calendrier.', style: theme.textTheme.bodySmall),
          const SizedBox(height: 12),
          SizedBox(
            height: 48,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: 42,
              separatorBuilder: (_, _) => const SizedBox(width: 6),
              itemBuilder: (context, index) {
                final week = index + 1;
                return ChoiceChip(
                  label: Text('$week'),
                  selected: week == _selectedWeek,
                  onSelected: (_) => setState(() => _selectedWeek = week),
                  tooltip: 'Semaine $week',
                );
              },
            ),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary,
              borderRadius: BorderRadius.circular(23),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_stage.toUpperCase(), style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onPrimary, letterSpacing: .8)),
              const SizedBox(height: 6),
              Text('Semaine $_selectedWeek', style: theme.textTheme.headlineLarge?.copyWith(color: theme.colorScheme.onPrimary, fontSize: 32)),
              const SizedBox(height: 12),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _selectedWeek / 40, minHeight: 7, backgroundColor: theme.colorScheme.onPrimary.withValues(alpha: .2), color: theme.colorScheme.onPrimary)),
              const SizedBox(height: 7),
              Text('Repère de calendrier indicatif · 40 semaines théoriques', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onPrimary.withValues(alpha: .85))),
            ]),
          ),
          const SizedBox(height: 15),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(Icons.event_note_outlined, color: theme.colorScheme.primary), const SizedBox(width: 9), Text('Ton repère de la semaine', style: theme.textTheme.titleLarge)]),
                const SizedBox(height: 9),
                Text(_focus, style: theme.textTheme.bodyLarge),
                const SizedBox(height: 10),
                Text('Tu peux enregistrer tes questions comme note lors d’un rendez-vous dans ton calendrier.', style: theme.textTheme.bodySmall),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(Icons.menu_book_outlined, color: theme.colorScheme.primary), const SizedBox(width: 9), Expanded(child: Text('Informations médicales de la semaine $_selectedWeek', style: theme.textTheme.titleMedium))]),
                const SizedBox(height: 8),
                Text('Le contenu hebdomadaire détaillé n’est pas encore intégré. Les informations sur le développement, les symptômes et les soins doivent être rédigées ou relues par des professionnels de santé avant diffusion.', style: theme.textTheme.bodyMedium),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: theme.colorScheme.secondary.withValues(alpha: .2), borderRadius: BorderRadius.circular(15)),
            child: Text('Né fournit un repère calendaire informatif, pas une surveillance médicale. Les semaines calculées ne remplacent pas le suivi prénatal.', style: theme.textTheme.bodySmall),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: _selectedWeek <= 1 ? null : () => setState(() => _selectedWeek--), icon: const Icon(Icons.chevron_left_rounded), label: const Text('Précédente'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: _selectedWeek >= 42 ? null : () => setState(() => _selectedWeek++), icon: const Icon(Icons.chevron_right_rounded), label: const Text('Suivante'), iconAlignment: IconAlignment.end)),
          ]),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import '../app_controller.dart';
import '../core/formatters.dart';
import '../models/appointment_model.dart';
import '../models/cycle_model.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();

  List<_CalendarEvent> _eventsFor(DateTime day) {
    final key = DateTime(day.year, day.month, day.day);
    final events = <_CalendarEvent>[];
    for (final cycle in widget.controller.cycles) {
      final start = _day(cycle.startDate);
      final end = start.add(Duration(days: cycle.periodLength - 1));
      if (!key.isBefore(start) && !key.isAfter(end)) {
        events.add(const _CalendarEvent('Règles notées', _EventKind.period));
      }
    }
    final prediction = widget.controller.cyclePrediction;
    if (prediction != null) {
      final periodStart = _day(prediction.nextPeriodStart);
      final periodEnd = periodStart.add(Duration(days: prediction.periodLength - 1));
      if (!key.isBefore(periodStart) && !key.isAfter(periodEnd)) {
        events.add(const _CalendarEvent('Règles estimées', _EventKind.estimate));
      }
      final fertileStart = _day(prediction.fertilityStart);
      final fertileEnd = _day(prediction.fertilityEnd);
      if (!key.isBefore(fertileStart) && !key.isAfter(fertileEnd)) {
        events.add(const _CalendarEvent('Fenêtre fertile estimée', _EventKind.fertile));
      }
    }
    for (final appointment in widget.controller.appointments) {
      if (_sameDay(key, appointment.dateTime)) {
        events.add(_CalendarEvent(appointment.title, _EventKind.appointment, appointment: appointment));
      }
    }
    return events;
  }

  DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final selectedEvents = _eventsFor(_selectedDay);
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 22),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(9, 10, 9, 8),
            child: TableCalendar<_CalendarEvent>(
              locale: 'fr_FR',
              firstDay: DateTime.utc(1990, 1, 1),
              lastDay: DateTime.utc(2100, 12, 31),
              focusedDay: _focusedDay,
              calendarFormat: CalendarFormat.month,
              availableCalendarFormats: const {CalendarFormat.month: 'Mois'},
              selectedDayPredicate: (day) => _sameDay(day, _selectedDay),
              eventLoader: _eventsFor,
              onDaySelected: (selected, focused) => setState(() { _selectedDay = selected; _focusedDay = focused; }),
              onPageChanged: (focused) => _focusedDay = focused,
              headerStyle: HeaderStyle(
                titleCentered: true,
                formatButtonVisible: false,
                titleTextStyle: theme.textTheme.titleLarge!,
                leftChevronIcon: Icon(Icons.chevron_left_rounded, color: theme.colorScheme.primary),
                rightChevronIcon: Icon(Icons.chevron_right_rounded, color: theme.colorScheme.primary),
              ),
              daysOfWeekStyle: DaysOfWeekStyle(
                weekdayStyle: theme.textTheme.bodySmall!,
                weekendStyle: theme.textTheme.bodySmall!.copyWith(color: theme.colorScheme.primary),
              ),
              calendarStyle: CalendarStyle(
                outsideDaysVisible: false,
                todayDecoration: BoxDecoration(color: theme.colorScheme.secondary.withValues(alpha: .45), shape: BoxShape.circle),
                selectedDecoration: BoxDecoration(color: theme.colorScheme.primary, shape: BoxShape.circle),
                defaultTextStyle: theme.textTheme.bodyMedium!,
                weekendTextStyle: theme.textTheme.bodyMedium!.copyWith(color: theme.colorScheme.primary),
                markerDecoration: BoxDecoration(color: theme.colorScheme.primary, shape: BoxShape.circle),
                markersMaxCount: 3,
                cellMargin: const EdgeInsets.all(5),
                cellPadding: const EdgeInsets.all(2),
              ),
              calendarBuilders: CalendarBuilders(
                markerBuilder: (context, day, events) {
                  if (events.isEmpty) return const SizedBox.shrink();
                  final kinds = events.cast<_CalendarEvent>().map((e) => e.kind).toSet();
                  return Positioned(
                    bottom: 3,
                    child: Row(mainAxisSize: MainAxisSize.min, children: kinds.take(3).map((kind) => Container(
                      width: 5,
                      height: 5,
                      margin: const EdgeInsets.symmetric(horizontal: 1),
                      decoration: BoxDecoration(color: _eventColor(context, kind), shape: BoxShape.circle),
                    )).toList()),
                  );
                },
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 12, runSpacing: 7, children: [
          _Legend(color: theme.colorScheme.primary, label: 'Règles notées'),
          const _Legend(color: Color(0xFF859A72), label: 'Fenêtre fertile estimée'),
          const _Legend(color: Color(0xFFD1A23F), label: 'Rendez-vous'),
          _Legend(color: theme.colorScheme.secondary, label: 'Dates estimées'),
        ]),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(formatDate(_selectedDay), style: theme.textTheme.titleLarge),
          TextButton.icon(
            onPressed: () => showCycleEntry(context, widget.controller, initialDate: _selectedDay),
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Noter les règles'),
          ),
        ]),
        if (selectedEvents.isEmpty)
          Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('Aucun repère enregistré pour cette date.', style: theme.textTheme.bodySmall))
        else
          ...selectedEvents.map((event) => Card(
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: _eventColor(context, event.kind).withValues(alpha: .18), child: Icon(_eventIcon(event.kind), color: _eventColor(context, event.kind), size: 19)),
                  title: Text(event.label),
                  subtitle: event.kind == _EventKind.appointment && event.appointment != null
                      ? Text('${event.appointment!.dateTime.hour.toString().padLeft(2, '0')}:${event.appointment!.dateTime.minute.toString().padLeft(2, '0')}')
                      : null,
                ),
              )),
        const SizedBox(height: 10),
        Text('Les fenêtres et dates futures sont estimatives. En cas de différence avec les repères de ton professionnel de santé, suis ses conseils.', style: theme.textTheme.bodySmall),
      ],
    );
  }

  Color _eventColor(BuildContext context, _EventKind kind) => switch (kind) {
        _EventKind.period => Theme.of(context).colorScheme.primary,
        _EventKind.estimate => Theme.of(context).colorScheme.secondary,
        _EventKind.fertile => const Color(0xFF859A72),
        _EventKind.appointment => const Color(0xFFD1A23F),
      };

  IconData _eventIcon(_EventKind kind) => switch (kind) {
        _EventKind.period => Icons.water_drop_outlined,
        _EventKind.estimate => Icons.auto_awesome_outlined,
        _EventKind.fertile => Icons.eco_outlined,
        _EventKind.appointment => Icons.event_note_outlined,
      };
}

Future<void> showCycleEntry(BuildContext context, AppController controller, {DateTime? initialDate}) async {
  // Reuse the home form through the public entry point shown on the dashboard.
  // The calendar uses a separate lightweight date picker path to keep the
  // selected day prefilled without coupling page state to the form internals.
  final picked = await showDatePicker(
    context: context,
    initialDate: initialDate ?? DateTime.now(),
    firstDate: DateTime(1990),
    lastDate: DateTime.now().add(const Duration(days: 1)),
    helpText: 'Choisir le premier jour des règles',
  );
  if (picked == null || !context.mounted) return;
  final shouldSave = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Noter le début des règles ?'),
      content: Text('Enregistrer le ${formatDate(picked)} comme premier jour des règles ? La durée du cycle de référence sera de 28 jours et pourra être modifiée lors d’un autre enregistrement.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Enregistrer')),
      ],
    ),
  );
  if (shouldSave == true) {
    try {
      await controller.saveCycle(CycleRecord(startDate: picked, cycleLength: 28, periodLength: 5));
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Date enregistrée. Tu peux ajuster la durée depuis Accueil.')));
    } catch (_) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cette date existe déjà ou n’a pas pu être enregistrée.')));
    }
  }
}

class _CalendarEvent {
  const _CalendarEvent(this.label, this.kind, {this.appointment});
  final String label;
  final _EventKind kind;
  final AppointmentRecord? appointment;
}

enum _EventKind { period, estimate, fertile, appointment }

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.label});
  final Color color;
  final String label;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)), const SizedBox(width: 5), Text(label, style: Theme.of(context).textTheme.bodySmall)]);
}

import 'package:flutter/material.dart';

import '../models/article_model.dart';
import '../services/article_service.dart';

class ArticlesScreen extends StatefulWidget {
  const ArticlesScreen({super.key});

  @override
  State<ArticlesScreen> createState() => _ArticlesScreenState();
}

class _ArticlesScreenState extends State<ArticlesScreen> {
  final Future<List<ArticleModel>> _articles = ArticleService().loadAll();
  String _category = 'Tout';
  final List<String> _categories = const ['Tout', 'Cycle', 'Fertilité', 'Grossesse', 'Bien-être', 'Puberté'];

  @override
  Widget build(BuildContext context) => FutureBuilder<List<ArticleModel>>(
        future: _articles,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text('Les articles hors ligne n’ont pas pu être chargés.'));
          }
          final articles = snapshot.data!
              .where((article) => _category == 'Tout' || article.category == _category)
              .toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 25),
            children: [
              Text('Des repères simples', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 5),
              Text('À lire à ton rythme, même sans connexion.', style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary.withValues(alpha: .22),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.fact_check_outlined, color: Theme.of(context).colorScheme.primary, size: 19),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Contenus de démonstration : une relecture par des professionnels de santé et une adaptation au contexte local sont nécessaires avant diffusion.', style: Theme.of(context).textTheme.bodySmall)),
                ]),
              ),
              const SizedBox(height: 14),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: _categories.map((category) => Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(label: Text(category), selected: _category == category, onSelected: (_) => setState(() => _category = category)),
                )).toList()),
              ),
              const SizedBox(height: 12),
              ...articles.map((article) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => _openArticle(context, article),
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Container(width: 42, height: 42, decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondary.withValues(alpha: .35), shape: BoxShape.circle), child: Icon(_iconFor(article.category), color: Theme.of(context).colorScheme.primary)),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(article.category.toUpperCase(), style: Theme.of(context).textTheme.bodySmall?.copyWith(letterSpacing: .8, fontSize: 9)),
                              const SizedBox(height: 3),
                              Text(article.title, style: Theme.of(context).textTheme.titleMedium),
                              const SizedBox(height: 5),
                              Text(article.summary, style: Theme.of(context).textTheme.bodySmall),
                              const SizedBox(height: 6),
                              Text('${article.readingMinutes} min de lecture · hors ligne', style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
                            ])),
                            Icon(Icons.chevron_right_rounded, color: Theme.of(context).colorScheme.primary),
                          ]),
                        ),
                      ),
                    ),
                  )),
            ],
          );
        },
      );

  IconData _iconFor(String category) => switch (category) {
        'Cycle' => Icons.water_drop_outlined,
        'Fertilité' => Icons.eco_outlined,
        'Grossesse' => Icons.favorite_border_rounded,
        'Puberté' => Icons.auto_awesome_outlined,
        _ => Icons.spa_outlined,
      };

  Future<void> _openArticle(BuildContext context, ArticleModel article) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .72,
        minChildSize: .45,
        maxChildSize: .94,
        builder: (context, scrollController) => ListView(
          controller: scrollController,
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
          children: [
            Text(article.category.toUpperCase(), style: Theme.of(context).textTheme.bodySmall?.copyWith(letterSpacing: .9)),
            const SizedBox(height: 5),
            Text(article.title, style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('${article.readingMinutes} min de lecture · accessible hors ligne', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 18),
            Text(article.body, style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 18),
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondary.withValues(alpha: .2), borderRadius: BorderRadius.circular(14)), child: Text('Ce contenu est une démonstration. Il ne remplace pas un avis médical et devra être validé avant publication.', style: Theme.of(context).textTheme.bodySmall)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models/appointment_model.dart';
import 'models/cycle_model.dart';
import 'models/cycle_prediction.dart';
import 'models/profile_model.dart';
import 'services/database_service.dart';
import 'services/notification_service.dart';
import 'services/prediction_service.dart';

class AppController extends ChangeNotifier {
  AppController._(this._db, this._prefs);

  final DatabaseService _db;
  final SharedPreferences _prefs;
  final PredictionService predictionService = const PredictionService();

  UserProfile profile = const UserProfile(nickname: '', goal: UserGoal.cycle);
  List<CycleRecord> cycles = const [];
  List<AppointmentRecord> appointments = const [];
  bool ready = false;
  bool onboardingComplete = false;
  bool remindersEnabled = false;
  int cycleReminderDays = 2;
  ThemeMode themeMode = ThemeMode.light;
  String languageCode = 'fr';
  String lastError = '';

  static Future<AppController> create() async {
    final prefs = await SharedPreferences.getInstance();
    final controller = AppController._(DatabaseService.instance, prefs);
    try {
      await NotificationService.instance.initialize();
    } catch (_) {
      // L’application reste utilisable si les notifications ne sont pas disponibles.
    }
    await controller._load();
    return controller;
  }

  Future<void> _load() async {
    lastError = '';
    try {
      profile = await _db.loadProfile() ?? profile;
      cycles = await _db.loadCycles();
      appointments = await _db.loadAppointments();
      onboardingComplete = _prefs.getBool('onboarding_complete') ?? false;
      remindersEnabled = _prefs.getBool('reminders_enabled') ?? false;
      cycleReminderDays = _prefs.getInt('cycle_reminder_days') ?? 2;
      themeMode = (_prefs.getString('theme') ?? 'light') == 'dark'
          ? ThemeMode.dark
          : ThemeMode.light;
      languageCode = _prefs.getString('language') ?? 'fr';
    } catch (_) {
      lastError = 'Impossible d’ouvrir les données locales. Réessaie ou efface les données de l’application.';
    }
    ready = true;
    notifyListeners();
  }

  void _reportError(Object error) {
    lastError = error.toString();
    notifyListeners();
  }

  Future<void> finishOnboarding({required String nickname, required UserGoal goal}) async {
    profile = profile.copyWith(nickname: nickname.trim(), goal: goal);
    await _db.saveProfile(profile);
    await _prefs.setBool('onboarding_complete', true);
    onboardingComplete = true;
    lastError = '';
    notifyListeners();
  }

  Future<void> updateProfile(UserProfile value) async {
    try {
      await _db.saveProfile(value);
      profile = value;
      lastError = '';
      notifyListeners();
    } catch (error) {
      _reportError(error);
      rethrow;
    }
  }

  Future<void> saveCycle(CycleRecord cycle) async {
    try {
      await _db.saveCycle(cycle);
      cycles = await _db.loadCycles();
      lastError = '';
      notifyListeners();
      await _scheduleCycleReminder();
    } catch (error) {
      _reportError(error);
      rethrow;
    }
  }

  Future<void> deleteCycle(CycleRecord cycle) async {
    if (cycle.id == null) return;
    await _db.deleteCycle(cycle.id!);
    cycles = await _db.loadCycles();
    notifyListeners();
    await _scheduleCycleReminder();
  }

  CyclePredictionView? get cyclePrediction {
    final result = predictionService.predict(cycles);
    if (result == null) return null;
    return CyclePredictionView(
      nextPeriodStart: result.nextPeriodStart,
      cycleDay: result.cycleDay,
      cycleLength: result.averageCycleLength,
      periodLength: result.periodLength,
      fertilityStart: result.fertilityWindowStart,
      fertilityEnd: result.fertilityWindowEnd,
      ovulation: result.ovulationDate,
      reliabilityLabel: result.reliability.label,
      reliability: result.reliability,
      sampleCount: result.sampleCount,
    );
  }

  Future<void> addAppointment(AppointmentRecord appointment) async {
    try {
      final id = await _db.saveAppointment(appointment);
      appointments = await _db.loadAppointments();
      lastError = '';
      notifyListeners();
      final saved = appointments.firstWhere((item) => item.id == id);
      await NotificationService.instance.scheduleAppointmentReminder(
        appointment: saved,
        enabled: remindersEnabled,
      );
    } catch (error) {
      _reportError(error);
      rethrow;
    }
  }

  Future<void> deleteAppointment(AppointmentRecord appointment) async {
    if (appointment.id == null) return;
    await _db.deleteAppointment(appointment.id!);
    await NotificationService.instance.cancelAppointmentReminder(appointment.id!);
    appointments = await _db.loadAppointments();
    notifyListeners();
  }

  Future<bool> setRemindersEnabled(bool value) async {
    if (value) {
      final granted = await NotificationService.instance.requestPermission();
      if (!granted) {
        remindersEnabled = false;
        await _prefs.setBool('reminders_enabled', false);
        notifyListeners();
        return false;
      }
    }
    remindersEnabled = value;
    await _prefs.setBool('reminders_enabled', value);
    await _scheduleCycleReminder();
    for (final appointment in appointments) {
      await NotificationService.instance.scheduleAppointmentReminder(
        appointment: appointment,
        enabled: value,
      );
    }
    notifyListeners();
    return true;
  }

  Future<void> setCycleReminderDays(int days) async {
    if (![1, 2, 3].contains(days)) return;
    cycleReminderDays = days;
    await _prefs.setInt('cycle_reminder_days', days);
    await _scheduleCycleReminder();
    notifyListeners();
  }

  Future<void> _scheduleCycleReminder() async {
    final prediction = predictionService.predict(cycles);
    if (prediction == null) {
      await NotificationService.instance.cancelCycleReminder();
      return;
    }
    await NotificationService.instance.scheduleCycleReminder(
      nextPeriodDate: prediction.nextPeriodStart,
      daysBefore: cycleReminderDays,
      enabled: remindersEnabled,
    );
  }

  Future<void> setTheme(ThemeMode value) async {
    themeMode = value;
    await _prefs.setString('theme', value == ThemeMode.dark ? 'dark' : 'light');
    notifyListeners();
  }

  Future<void> setLanguage(String value) async {
    if (value != 'fr') return;
    languageCode = value;
    await _prefs.setString('language', value);
    notifyListeners();
  }

  Future<Map<String, dynamic>> exportData() async {
    final snapshot = await _db.exportSnapshot();
    snapshot['preferences'] = {
      'theme': themeMode == ThemeMode.dark ? 'dark' : 'light',
      'language': languageCode,
      'reminders_enabled': remindersEnabled,
      'cycle_reminder_days': cycleReminderDays,
    };
    return snapshot;
  }

  Future<void> eraseAllData() async {
    await NotificationService.instance.cancelAll();
    await _db.eraseEverything();
    await _prefs.clear();
    profile = const UserProfile(nickname: '', goal: UserGoal.cycle);
    cycles = const [];
    appointments = const [];
    onboardingComplete = false;
    remindersEnabled = false;
    cycleReminderDays = 2;
    themeMode = ThemeMode.light;
    languageCode = 'fr';
    lastError = '';
    await _load();
  }
}

class CyclePredictionView {
  const CyclePredictionView({
    required this.nextPeriodStart,
    required this.cycleDay,
    required this.cycleLength,
    required this.periodLength,
    required this.fertilityStart,
    required this.fertilityEnd,
    required this.ovulation,
    required this.reliabilityLabel,
    required this.reliability,
    required this.sampleCount,
  });

  final DateTime nextPeriodStart;
  final int cycleDay;
  final int cycleLength;
  final int periodLength;
  final DateTime fertilityStart;
  final DateTime fertilityEnd;
  final DateTime ovulation;
  final String reliabilityLabel;
  final ReliabilityLevel reliability;
  final int sampleCount;
}

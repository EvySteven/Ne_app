import 'package:flutter/material.dart';

class NeTheme {
  static const Color lightPrimary = Color(0xFFB7446E);
  static const Color lightRose = Color(0xFFF5C4D3);
  static const Color lightBackground = Color(0xFFFFF8F7);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color darkPrimary = Color(0xFFE99AB3);
  static const Color darkBackground = Color(0xFF1A0A10);
  static const Color darkSurface = Color(0xFF28151D);

  static ThemeData light() => _build(
        brightness: Brightness.light,
        primary: lightPrimary,
        background: lightBackground,
        surface: lightSurface,
        secondary: lightRose,
        ink: const Color(0xFF38232D),
        muted: const Color(0xFF806B74),
        outline: const Color(0xFFEEDCE2),
      );

  static ThemeData dark() => _build(
        brightness: Brightness.dark,
        primary: darkPrimary,
        background: darkBackground,
        surface: darkSurface,
        secondary: const Color(0xFF633447),
        ink: const Color(0xFFFFF0F3),
        muted: const Color(0xFFC4AAB4),
        outline: const Color(0xFF4B303A),
      );

  static ThemeData _build({
    required Brightness brightness,
    required Color primary,
    required Color background,
    required Color surface,
    required Color secondary,
    required Color ink,
    required Color muted,
    required Color outline,
  }) {
    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: brightness,
      surface: surface,
      primary: primary,
      secondary: secondary,
      outline: outline,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      fontFamily: 'sans-serif',
      textTheme: TextTheme(
        headlineLarge: TextStyle(fontFamily: 'serif', color: ink, fontSize: 30, height: 1.15, fontWeight: FontWeight.w600),
        headlineMedium: TextStyle(fontFamily: 'serif', color: ink, fontSize: 25, height: 1.18, fontWeight: FontWeight.w600),
        titleLarge: TextStyle(fontFamily: 'serif', color: ink, fontSize: 20, fontWeight: FontWeight.w600),
        titleMedium: TextStyle(color: ink, fontSize: 15, fontWeight: FontWeight.w700),
        bodyLarge: TextStyle(color: ink, fontSize: 14, height: 1.5),
        bodyMedium: TextStyle(color: ink, fontSize: 13, height: 1.45),
        bodySmall: TextStyle(color: muted, fontSize: 11, height: 1.4),
        labelLarge: TextStyle(color: ink, fontSize: 13, fontWeight: FontWeight.w700),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: ink,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(fontFamily: 'serif', color: ink, fontSize: 21, fontWeight: FontWeight.w600),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: outline),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: primary, width: 1.6),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: secondary.withValues(alpha: .45),
        labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
              fontSize: 10,
              fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
              color: states.contains(WidgetState.selected) ? primary : muted,
            )),
      ),
      dividerColor: outline,
    );
  }
}

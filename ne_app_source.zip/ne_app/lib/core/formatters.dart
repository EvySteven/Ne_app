import 'package:intl/intl.dart';

final DateFormat neDateFormat = DateFormat('d MMMM yyyy', 'fr');
final DateFormat neShortDateFormat = DateFormat('d MMM', 'fr');
final DateFormat neDateTimeFormat = DateFormat('d MMM yyyy à HH:mm', 'fr');

String formatDate(DateTime? value) =>
    value == null ? '—' : neDateFormat.format(value);

String formatShortDate(DateTime? value) =>
    value == null ? '—' : neShortDateFormat.format(value);

String formatDateTime(DateTime? value) =>
    value == null ? '—' : neDateTimeFormat.format(value);

import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

class AnoushkaReply {
  const AnoushkaReply({required this.text, this.source});
  final String text;
  final String? source;
}

/// Client vers l’origine choisie par la fondatrice.
/// Seuls le texte explicitement saisi et un identifiant de session aléatoire
/// éphémère sont envoyés. Aucun contexte Né n’est ajouté au payload.
class AnoushkaClient {
  AnoushkaClient({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const String _baseUrl = String.fromEnvironment(
    'ANOUSHKA_API_BASE_URL',
    defaultValue: 'https://anoushka.onrender.com',
  );

  bool get isConfigured => _baseUrl.trim().isNotEmpty;
  String get configuredHost => Uri.parse(_baseUrl).host;

  Future<AnoushkaReply> ask(String question, String sessionId) async {
    if (!isConfigured) {
      throw StateError('La connexion à Anoushka n’est pas configurée.');
    }
    final base = Uri.parse(_baseUrl);
    if (base.scheme != 'https') {
      throw StateError('L’API Anoushka doit utiliser HTTPS.');
    }
    final endpoint = base.resolve('/api/chat');
    final response = await _client
        .post(
          endpoint,
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({'message': question, 'session_id': sessionId}),
        )
        .timeout(const Duration(seconds: 90));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Anoushka est momentanément indisponible.');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final text = data['reponse'] as String?;
    if (text == null || text.trim().isEmpty) {
      throw const FormatException('La réponse de l’API est vide ou invalide.');
    }
    return AnoushkaReply(text: text, source: data['source'] as String?);
  }

  static String createEphemeralSessionId() {
    final random = Random.secure();
    final suffix = List<int>.generate(10, (_) => random.nextInt(256));
    return 'session_${DateTime.now().millisecondsSinceEpoch}_${base64UrlEncode(suffix)}';
  }

  void close() => _client.close();
}

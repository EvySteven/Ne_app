import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../models/appointment_model.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  static const int _cycleReminderId = 1101;

  Future<void> initialize() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    try {
      final zone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zone.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.UTC);
    }
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _plugin.initialize(settings: settings);
    _initialized = true;
  }

  Future<bool> requestPermission() async {
    await initialize();
    final android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return false;
    final alreadyEnabled = await android.areNotificationsEnabled();
    if (alreadyEnabled == true) return true;
    final permissionResult = await android.requestNotificationsPermission();
    if (permissionResult != null) return permissionResult;
    return await android.areNotificationsEnabled() ?? false;
  }

  Future<void> scheduleCycleReminder({
    required DateTime nextPeriodDate,
    required int daysBefore,
    required bool enabled,
  }) async {
    await initialize();
    await cancelCycleReminder();
    if (!enabled) return;
    final reminderDay = DateTime(nextPeriodDate.year, nextPeriodDate.month, nextPeriodDate.day)
        .subtract(Duration(days: daysBefore));
    final scheduled = DateTime(reminderDay.year, reminderDay.month, reminderDay.day, 9);
    if (!scheduled.isAfter(DateTime.now())) return;
    await _schedule(
      id: _cycleReminderId,
      when: scheduled,
      title: 'Né',
      body: 'Tu as un rappel prévu. Ouvre Né pour consulter tes repères.',
    );
  }

  Future<void> cancelCycleReminder() async {
    await initialize();
    await _plugin.cancel(id: _cycleReminderId);
  }

  Future<void> scheduleAppointmentReminder({
    required AppointmentRecord appointment,
    required bool enabled,
  }) async {
    await initialize();
    if (appointment.id == null) return;
    final id = 2000 + appointment.id!;
    await _plugin.cancel(id: id);
    if (!enabled) return;
    final when = appointment.dateTime.subtract(Duration(minutes: appointment.reminderMinutes));
    if (!when.isAfter(DateTime.now())) return;
    await _schedule(
      id: id,
      when: when,
      title: 'Né · rappel',
      body: 'Tu as un rappel enregistré. Ouvre Né pour consulter les détails.',
    );
  }

  Future<void> cancelAppointmentReminder(int appointmentId) async {
    await initialize();
    await _plugin.cancel(id: 2000 + appointmentId);
  }

  Future<void> _schedule({required int id, required DateTime when, required String title, required String body}) async {
    await _plugin.zonedSchedule(
      id: id,
      title: title,
      body: body,
      scheduledDate: tz.TZDateTime.from(when, tz.local),
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          'ne_private_reminders',
          'Rappels Né',
          channelDescription: 'Rappels locaux au contenu discret.',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
          visibility: NotificationVisibility.private,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: 'home',
    );
  }

  Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }
}

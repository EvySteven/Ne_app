import 'dart:math' as math;

import '../models/cycle_model.dart';
import '../models/cycle_prediction.dart';

class PredictionService {
  const PredictionService();

  CyclePrediction? predict(List<CycleRecord> records, {DateTime? today}) {
    if (records.isEmpty) return null;
    final now = _day(today ?? DateTime.now());
    final ordered = [...records]..sort((a, b) => a.startDate.compareTo(b.startDate));
    final last = ordered.last;

    // Une durée déclarée n'est pas comptée comme observation. Dès qu'il y a
    // plusieurs débuts de règles, seules les distances entre dates réelles
    // contribuent à la fiabilité et à la moyenne prédictive.
    final measuredLengths = <int>[];
    for (var index = 0; index < ordered.length - 1; index++) {
      final elapsed = _day(ordered[index + 1].startDate)
          .difference(_day(ordered[index].startDate))
          .inDays;
      if (elapsed >= 15 && elapsed <= 60) measuredLengths.add(elapsed);
    }
    final lengths = measuredLengths.isEmpty
        ? <int>[last.cycleLength]
        : measuredLengths;
    final filtered = _filterOutliers(lengths);
    final average = _weightedAverage(filtered);
    final sigma = _standardDeviation(filtered);
    final observedCount = measuredLengths.isEmpty ? 0 : filtered.length;
    final level = _reliability(observedCount, sigma);
    final nextStart = _day(last.startDate).add(Duration(days: average));
    final ovulation = nextStart.subtract(const Duration(days: 14));
    final daysSinceStart = now.difference(_day(last.startDate)).inDays;
    final cycleDay = daysSinceStart < 0 ? 1 : daysSinceStart + 1;

    return CyclePrediction(
      nextPeriodStart: nextStart,
      periodLength: _averagePeriodLength(ordered),
      averageCycleLength: average,
      standardDeviation: sigma,
      sampleCount: observedCount,
      cycleDay: cycleDay,
      reliability: level,
      fertilityWindowStart: ovulation.subtract(const Duration(days: 5)),
      fertilityWindowEnd: ovulation.add(const Duration(days: 1)),
      ovulationDate: ovulation,
    );
  }

  List<int> filterOutliers(List<int> cycleLengths) => _filterOutliers(cycleLengths);

  List<int> _filterOutliers(List<int> values) {
    if (values.length < 4) return [...values];
    final mean = values.reduce((a, b) => a + b) / values.length;
    final sigma = _standardDeviation(values);
    if (sigma == 0) return [...values];
    return values.where((value) => (value - mean).abs() <= 2 * sigma).toList();
  }

  int _weightedAverage(List<int> values) {
    if (values.isEmpty) return 28;
    var numerator = 0;
    var denominator = 0;
    for (var i = 0; i < values.length; i++) {
      final weight = i + 1;
      numerator += values[i] * weight;
      denominator += weight;
    }
    return (numerator / denominator).round().clamp(15, 60).toInt();
  }

  double _standardDeviation(List<int> values) {
    if (values.length < 2) return 0;
    final mean = values.reduce((a, b) => a + b) / values.length;
    final variance = values.fold<double>(
          0,
          (sum, value) => sum + math.pow(value - mean, 2).toDouble(),
        ) /
        values.length;
    return math.sqrt(variance);
  }

  ReliabilityLevel _reliability(int sampleCount, double sigma) {
    if (sampleCount < 3) return ReliabilityLevel.insufficient;
    if (sampleCount < 6) {
      return sigma <= 2 ? ReliabilityLevel.medium : ReliabilityLevel.low;
    }
    if (sigma <= 2) return ReliabilityLevel.high;
    if (sigma <= 5) return ReliabilityLevel.medium;
    return ReliabilityLevel.low;
  }

  int _averagePeriodLength(List<CycleRecord> records) {
    final values = records.map((r) => r.periodLength).toList();
    if (values.isEmpty) return 5;
    return (values.reduce((a, b) => a + b) / values.length).round().clamp(1, 15).toInt();
  }

  DateTime _day(DateTime value) => DateTime(value.year, value.month, value.day);
}

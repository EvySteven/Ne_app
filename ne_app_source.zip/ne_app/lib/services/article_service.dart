import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/article_model.dart';

class ArticleService {
  Future<List<ArticleModel>> loadAll() async {
    final raw = await rootBundle.loadString('assets/data/articles.json');
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((item) => ArticleModel.fromMap(item as Map<String, dynamic>))
        .toList(growable: false);
  }
}

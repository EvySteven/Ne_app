import '../models/profile_model.dart';

class PregnancyAge {
  const PregnancyAge({
    required this.weeks,
    required this.days,
    required this.usesConfirmedDueDate,
    required this.isWithinSupportedRange,
  });

  final int weeks;
  final int days;
  final bool usesConfirmedDueDate;
  final bool isWithinSupportedRange;

  String get sourceLabel => usesConfirmedDueDate
      ? 'Calcul basé sur la date confirmée par un professionnel'
      : 'Estimation basée sur la date des dernières règles';
}

class PregnancyService {
  const PregnancyService();

  PregnancyAge? age(UserProfile profile, {DateTime? today}) {
    final now = _day(today ?? DateTime.now());
    final confirmedEdd = profile.dueDateConfirmed ? profile.confirmedDueDate : null;
    final DateTime? anchor = confirmedEdd ?? profile.lastMenstrualPeriod;
    if (anchor == null) return null;

    final int gestationalDays;
    final bool usesEdd = confirmedEdd != null;
    if (usesEdd) {
      // Une date prévue correspond à 40 semaines d’aménorrhée (280 jours).
      gestationalDays = 280 - _day(anchor).difference(now).inDays;
    } else {
      gestationalDays = now.difference(_day(anchor)).inDays;
    }
    final weeks = gestationalDays < 0 ? 0 : gestationalDays ~/ 7 + 1;
    final days = gestationalDays < 0 ? 0 : gestationalDays % 7;

    return PregnancyAge(
      weeks: weeks,
      days: days,
      usesConfirmedDueDate: usesEdd,
      isWithinSupportedRange: gestationalDays >= 0 && gestationalDays <= 315,
    );
  }

  DateTime? estimatedDueDate(DateTime? lastMenstrualPeriod) =>
      lastMenstrualPeriod == null
          ? null
          : _day(lastMenstrualPeriod).add(const Duration(days: 280));

  DateTime _day(DateTime value) => DateTime(value.year, value.month, value.day);
}

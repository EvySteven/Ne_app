import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ExportService {
  Future<void> shareJson(Map<String, dynamic> data) async {
    final file = await _write('ne-export.json', const JsonEncoder.withIndent('  ').convert(data));
    try {
      await SharePlus.instance.share(
        ShareParams(
          title: 'Exporter mes données Né',
          text: 'Copie de tes données Né. Garde ce fichier dans un endroit sûr.',
          files: [XFile(file.path, mimeType: 'application/json')],
        ),
      );
    } finally {
      if (await file.exists()) await file.delete();
    }
  }

  Future<void> shareCsv(Map<String, dynamic> data) async {
    final rows = <List<Object?>>[
      ['type', 'id', 'date', 'valeur_1', 'valeur_2', 'notes'],
    ];
    final profile = data['profile'] as Map<String, dynamic>?;
    if (profile != null) {
      rows.add(['profil', 1, '', profile['nickname'], profile['goal'], '']);
      rows.add([
        'grossesse',
        1,
        profile['last_menstrual_period'] ?? '',
        profile['due_date'] ?? '',
        profile['due_date_confirmed'] ?? 0,
        '',
      ]);
    }
    final preferences = data['preferences'] as Map<String, dynamic>?;
    if (preferences != null) {
      rows.add([
        'preferences',
        '',
        '',
        preferences['theme'] ?? '',
        preferences['language'] ?? '',
        'rappels=${preferences['reminders_enabled'] ?? false}; jours_avant=${preferences['cycle_reminder_days'] ?? ''}',
      ]);
    }
    for (final item in (data['cycles'] as List<dynamic>? ?? const [])) {
      final cycle = item as Map<String, dynamic>;
      rows.add([
        'cycle',
        cycle['id'] ?? '',
        cycle['start_date'] ?? '',
        cycle['cycle_length'] ?? '',
        cycle['period_length'] ?? '',
        cycle['notes'] ?? '',
      ]);
    }
    for (final item in (data['appointments'] as List<dynamic>? ?? const [])) {
      final appointment = item as Map<String, dynamic>;
      rows.add([
        'rendez_vous',
        appointment['id'] ?? '',
        appointment['date_time'] ?? '',
        appointment['title'] ?? '',
        appointment['place'] ?? '',
        appointment['notes'] ?? '',
      ]);
    }
    final csv = rows.map((row) => row.map(_csvCell).join(',')).join('\r\n');
    final file = await _write('ne-export.csv', '\uFEFF$csv');
    try {
      await SharePlus.instance.share(
        ShareParams(
          title: 'Exporter mes données Né (CSV)',
          text: 'Copie CSV de tes données Né. Garde ce fichier dans un endroit sûr.',
          files: [XFile(file.path, mimeType: 'text/csv')],
        ),
      );
    } finally {
      if (await file.exists()) await file.delete();
    }
  }

  Future<File> _write(String name, String content) async {
    final temp = await getTemporaryDirectory();
    final file = File('${temp.path}/$name');
    return file.writeAsString(content, encoding: utf8, flush: true);
  }

  String _csvCell(Object? value) {
    final text = (value ?? '').toString();
    return '"${text.replaceAll('"', '""')}"';
  }
}

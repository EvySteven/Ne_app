package bf.ne.ne_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
